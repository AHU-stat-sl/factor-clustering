#!/usr/bin/env python3
"""Small, reproducible K-selection/over-specification diagnostic; no core reruns."""
import argparse,csv,itertools,json,math,os,time
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import numpy as np
import simulation_study as study
from group_count_selection import validation_group_counts,select_candidate

K_GRID=((2,2),(3,3),(4,4))
DELTAS=(0.,.005,.01,.02)
MASTER_SEED=20260918

def panel(b,n=60,t=60):
    rng=np.random.default_rng(np.random.SeedSequence([MASTER_SEED,b,0]))
    labels=np.repeat(np.array(list(itertools.product(range(2),repeat=2))),n//4,axis=0)
    labels=labels[rng.permutation(n)]
    loadings=(2*labels-1)*np.array([1.1,.9])
    f=rng.standard_normal((t,2))
    for j in range(1,t):f[j]=.3*f[j-1]+math.sqrt(.91)*f[j]
    f=f@np.linalg.inv(np.linalg.cholesky(f.T@f/t).T)
    e=rng.standard_normal((n,t))
    for i in range(1,n):e[i]=.3*e[i-1]+math.sqrt(.91)*e[i]
    return loadings@f.T+e,loadings,f,labels

def run(b):
    start=time.perf_counter();x,l,f,truth=panel(b)
    _,records=validation_group_counts(x,K_GRID,np.random.default_rng(np.random.SeedSequence([MASTER_SEED,b,1])))
    choices={f'CV+parsimony-{delta:g}':select_candidate(records,delta) for delta in DELTAS}
    for k in [(2,2),(4,4)]:
        choices['fixed-'+str(k)]=select_candidate([r for r in records if tuple(r['group_counts'])==k],0)
    fits={};results=[]
    for name,chosen in choices.items():
        if chosen is None:
            results.append(dict(replication=b,rule=name,valid=0,exact=0));continue
        k=tuple(chosen['group_counts']);ratio=chosen['alpha_over_sqrt_train'];key=(k,ratio)
        if key not in fits:
            seed=np.random.SeedSequence([MASTER_SEED,b,2,*k,int(round(100*ratio))])
            fits[key]=study.mdsp_full_sample_with_retry(x,k,ratio*math.sqrt(x.shape[1]),np.random.default_rng(seed))
        ll,ff,labels,_,diag=fits[key]
        met=study.metrics(ll,ff,labels,l,f,truth,study.profile_codes(truth),(2,2))
        active=tuple(map(int,diag['active_group_counts'].split(',')))
        valid=int(diag['converged'])
        results.append(dict(replication=b,rule=name,requested_k=str(k),active_k=str(active),
            requested_true=int(k==(2,2)),active_true=int(active==(2,2)),active_total=sum(active),
            training_active_total=sum(map(int,chosen['active_group_counts'].split(','))),
            alpha_ratio=ratio,cv=chosen['validation_mse'],valid=valid,
            common_re=met['common_re'] if valid else math.nan,
            mcr=met['mcr'] if valid else math.nan,ari=met['ari'] if valid else math.nan,
            exact=met['exact'] if valid else 0,
            iterations=diag['iterations'],failure_reason=diag['failure_reason']))
    for r in records:r['replication']=b
    return results,records,time.perf_counter()-start

def writecsv(path,rows):
    keys=sorted(set().union(*(r.keys() for r in rows)))
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)

def orientation_diagnostic(out):
    # Exact least-squares grouping via all contiguous partitions of four levels.
    l=np.array(list(itertools.product([-1.1,1.1],[-.9,.9])))
    rows=[]
    for degrees in np.linspace(0,90,181):
        a=np.deg2rad(degrees);rot=np.array([[np.cos(a),-np.sin(a)],[np.sin(a),np.cos(a)]])
        z=l@rot
        for k in [2,3,4]:
            loss=0.
            for s in range(2):
                y=np.sort(z[:,s]);best=math.inf
                for cuts in itertools.combinations(range(1,4),k-1):
                    groups=np.split(y,cuts)
                    best=min(best,sum(float(np.sum((g-g.mean())**2)) for g in groups))
                loss+=best/4
            rows.append(dict(angle=degrees,k=k,orientation_loss=loss))
    writecsv(out/'orientation_loss.csv',rows)
    assert max(r['orientation_loss'] for r in rows if r['k']==4)<1e-25

def main():
    p=argparse.ArgumentParser();p.add_argument('--replications',type=int,default=50);p.add_argument('--workers',type=int,default=4);p.add_argument('--out',type=Path,required=True);args=p.parse_args()
    args.out.mkdir(parents=True,exist_ok=True)
    metadata=dict(master_seed=MASTER_SEED,N=60,T=60,r=2,replications=args.replications,K_grid=K_GRID,relative_tolerances=DELTAS,primary_tolerance=.01,config=study.asdict(study.CONFIG),numpy=np.__version__)
    (args.out/'design.json').write_text(json.dumps(metadata,indent=2))
    orientation_diagnostic(args.out)
    rows=[];audit=[]
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for i,(res,rec,elapsed) in enumerate(pool.map(run,range(args.replications))):
            rows+=res;audit+=rec
            writecsv(args.out/'replications.csv',rows);writecsv(args.out/'validation_audit.csv',audit)
            print(f'{i+1}/{args.replications}: {elapsed:.1f}s, invalid={sum(1-r["valid"] for r in res)}',flush=True)
    summary=[]
    for rule in sorted(set(r['rule'] for r in rows)):
        rr=[r for r in rows if r['rule']==rule];v=dict(rule=rule,B=len(rr))
        for metric in ['requested_true','active_true','active_total','cv','common_re','mcr','ari','exact','valid']:
            values=np.array([r.get(metric,math.nan) for r in rr]);values=values[np.isfinite(values)]
            v[metric]=float(np.mean(values)) if len(values) else math.nan
            v['se_'+metric]=float(np.std(values,ddof=1)/np.sqrt(len(values))) if len(values)>1 else math.nan
        summary.append(v)
    writecsv(args.out/'summary.csv',summary)
if __name__=='__main__':main()
