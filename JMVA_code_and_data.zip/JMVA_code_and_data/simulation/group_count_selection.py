"""Joint K/alpha validation with a prespecified parsimony tolerance.

This is a predictive tie-break, not an identification or selection-consistency
result. Fixed-K core experiments continue to use their original alpha selector.
"""
from __future__ import annotations
import math
import numpy as np
import simulation_study as study


def select_candidate(records, relative_tolerance=0.01):
    """Among valid scores within (1+delta)*minimum, minimize active centers.

Remaining ties: validation loss, requested center budget, K tuple, alpha.
Active counts are those from the training fit, never truth or full-sample data.
"""
    if not math.isfinite(relative_tolerance) or relative_tolerance < 0:
        raise ValueError('relative_tolerance must be finite and nonnegative')
    valid = [r for r in records if r['final_candidate'] and r['converged']
             and math.isfinite(r['validation_mse']) and r['validation_mse'] >= 0]
    if not valid:
        return None
    best = min(r['validation_mse'] for r in valid)
    eligible = [r for r in valid if r['validation_mse'] <= (1+relative_tolerance)*best]
    def key(r):
        active = tuple(map(int, r['active_group_counts'].split(',')))
        requested = tuple(r['group_counts'])
        return (sum(active), r['validation_mse'], sum(requested), requested,
                r['alpha_over_sqrt_train'])
    return min(eligible, key=key)


def validation_group_counts(x, candidates, rng, relative_tolerance=0.01,
                            grid_ratios=study.CONFIG.alpha_ratios):
    """Fit the full K/alpha grid under the existing strict recovery rules."""
    grid = sorted(set(tuple(k) for k in candidates))
    if not grid or any(len(k) != len(grid[0]) or min(k) < 1 for k in grid):
        raise ValueError('nonempty positive group-count vectors of equal dimension required')
    if any(max(k) > x.shape[0] for k in grid):
        raise ValueError('group counts cannot exceed N')
    # A common stream gives equal initialization budgets without favoring K order.
    seed = int(rng.integers(0, 2**32-1))
    records = []
    for k in grid:
        _, audit = study.validation_alpha(x, k, np.random.default_rng(seed),
                                         return_diagnostics=True, grid_ratios=grid_ratios)
        for row in audit:
            row = dict(row, group_counts=k, selected=0)
            records.append(row)
    selected = select_candidate(records, relative_tolerance)
    if selected is not None:
        selected['selected'] = 1
    return selected, records
