"""Generate manuscript simulations without loading any previous results."""
import argparse
import multiprocessing as mp
import platform
import time
from pathlib import Path
from common import ROOT, readcsv, dump, check_core, fresh_directory
import simulation_study as s
import numpy as np

def task(row):
    return s.run_one(int(row['N']),int(row['T']),row['scenario'],int(row['seed']),
                     include_vector_benchmarks=False,mdsp_starts=s.CONFIG.final_starts)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--mode',choices=['full','smoke'],default='smoke')
    p.add_argument('--workers',type=int,default=4)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args()
    if a.workers<1:p.error('workers must be positive')
    check_core(s);out=fresh_directory(a.output)
    tasks=readcsv(ROOT/'configs/core_tasks.csv')
    if a.mode=='smoke':
        chosen=[]
        for sc,n,t in [('baseline',60,60),('partial',60,60),('pca_orientation_rho_40',120,120)]:
            chosen.append(next(q for q in tasks if q['scenario']==sc and int(q['N'])==n and int(q['T'])==t))
        for sc,n,t,seed in [('partial',60,60,2966754609),('baseline',120,60,1859202162)]:
            chosen.append(next(q for q in tasks if q['scenario']==sc and int(q['N'])==n and int(q['T'])==t and int(q['seed'])==seed))
        tasks=chosen
    tic=time.time();rows=[]
    with mp.get_context('spawn').Pool(a.workers) as pool:
        for i,result in enumerate(pool.imap(task,tasks,chunksize=1),1):
            rows.extend(result)
            if i%20==0 or i==len(tasks):
                s.write_csv_atomic(out/'replications.csv',rows)
                print(f'{i}/{len(tasks)} panels completed',flush=True)
    s.write_csv_atomic(out/'summary.csv',s.summarize(rows))
    invalid=sum(not r['statistical_fit_valid'] for r in rows if r['method']=='MDSP')
    dump(out/'run_info.json',dict(mode=a.mode,panels=len(tasks),method_rows=len(rows),
        mdsp_invalid=invalid,workers=a.workers,python=platform.python_version(),numpy=np.__version__,
        numerical_settings=s.asdict(s.CONFIG),elapsed_seconds=time.time()-tic))
    print(f'Finished. Invalid MDSP fits: {invalid}. Outputs: {out}',flush=True)

if __name__=='__main__':main()
