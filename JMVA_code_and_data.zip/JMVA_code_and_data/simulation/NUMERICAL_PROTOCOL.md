# Simulation numerical protocol

Frozen constants: `configs/protocol.json`. Panel seeds: `configs/core_tasks.csv`.

## 1. Data and dimensions

Matrices have observations/indicators in rows: X is N by T, loadings L are N by r,
and factors F are T by r. Fits satisfy F'F/T = I. Simulations do **not** demean
factors or X and do not standardize X. Empirical standardization is specified
separately below.

The main simulation uses r=3, B=200 per cell, and (N,T)=(60,60), (60,120),
(120,60), (120,120). The launcher retains 8,800 panels: 800 baseline, 800 partial
sharing, and 7,200 orientation stress. The four methods are PCA, PCA–KM, MDSP,
and Oracle–FS. K is known in these experiments; it is not estimated from truth
in the separate group-count diagnostic.

For each panel, generate loadings first. Generate a T by r array of independent
standard Gaussian innovations. The first raw factor row equals its innovation;
thereafter F0[t]=0.3 F0[t-1]+sqrt(1-0.3^2) innovation[t]. If C is the lower
Cholesky factor of F0'F0/T, set F=F0 inverse(C'). No sample demeaning occurs.
Independently draw a Gaussian N by T error array Z and set E[0]=Z[0],
E[i]=0.3 E[i-1]+sqrt(1-0.3^2) Z[i]. Thus errors have cross-sectional AR(1)
correlation and are independent over time in these designs. Set X=L F'+E.

**Baseline:** K=(2,3,2), with centers (-1.4,1.4), (-1,0,1), and (-0.65,0.65).
All 12 crossed profiles occur equally often and their rows are randomly
permuted. This yields orthogonal loading columns with distinct second moments.

**Partial sharing:** use the same centers. The first label is Bernoulli(0.5).
Conditional second-label probabilities are (0.58,0.32,0.10) for first label 0
and (0.10,0.32,0.58) for first label 1. The third label equals the first with
probability 0.75. The implementation repairs a missing marginal group by
assigning a randomly chosen row; the exact repair order is in
`_ensure_nonempty_columns`. Memberships are otherwise randomly generated,
not forced to have fixed profile counts.

**Orientation stress:** K=(2,2,2), centers (+/-1.1), (+/-0.9), (+/-0.6), and
target rho=0,0.1,...,0.8. Let a=round(N(1+rho)/4) using Python's actual
floating-point `round`, and b=N/2-a. The (0,0),(1,1) pair cells each contain a
rows and the (0,1),(1,0) cells each contain b. Both same-sign cells have
floor(a/2) third-label ones; both opposite-sign cells have N/4-floor(a/2).
Then randomly permute all rows. All margins are exactly balanced, the third
column is orthogonal to the first two, and rho_real=4a/N-1. The Gram matrix is
[[1.21,0.99 rho_real,0],[0.99 rho_real,0.81,0],[0,0,0.36]]. Figure 2 uses
theta=0.5 atan2(1.98 rho_real,0.4) in degrees. This is the population PCA angle
implied by realized finite-N loading counts, **not** an angle estimated from
the noisy sample PCA. At N=60, not every target rho is exactly attainable.

## 2. Random streams and tie conventions

The historical simulation master seed is 20260819, but task order changed
across the original batches. The explicit retained seed list is authoritative:
do not create a new SeedSequence after omitting non-manuscript scenarios.
For each listed seed, use `default_rng(seed)` for the data. Method streams are
`SeedSequence([seed,20260909]).spawn(7)` in this order: pca_kmeans, tuning, mdsp,
oracle_fs, cv_budget, cv_profile, oracle_cv. Unused common-vector streams remain
reserved. Parallel workers never generate their own unrecorded panel seeds.

The pinned NumPy uses PCG64 through `default_rng`. Within a multistart call,
base-start seeds are drawn with `rng.integers(0,2**32-1)`; the upper endpoint is
excluded. Each start receives its own fresh generator. Preserve calls that
consume randomness even when their output is not reported. In particular,
PCA–KM consumes k-means randomness before drawing refit starts.

Nearest-center ties use the first minimum. Candidate selection uses the first
minimum in the ordered candidate list unless a lexicographic key is explicitly
given below. SVD/QR use NumPy's signs without imposing a new sign convention
during fitting. Cross-platform LAPACK differences can alter nonconvex paths;
fixed seeds alone do not imply platform-independent bitwise identity.

## 3. Initialization and discovery

PCA is the uncentered thin SVD X=U D V': L=U_r D_r/sqrt(T), F=sqrt(T) V_r.
For a rotated-PCA start, Q is obtained by QR decomposition of a fresh r by r
standard Gaussian matrix; replace (L,F) by (LQ,FQ). For a random start, QR a
T by r Gaussian matrix, set F=sqrt(T)Q and L=XF/T. A warm start copies the
provided L,F. Every discovery start resets the split variable Theta=L and
the unscaled dual variable to zero. Initialize each coordinate's K centers
by the exact one-dimensional dynamic-programming k-medians implementation
`exact_kmedians_1d` (stable data sort, lower interval median, first minimizing
split). Do not substitute library k-means for this initialization.

The discovery objective used for ranking is RSS + alpha times the sum of
nearest-center absolute deviations of **L**, not Theta. Selection is among
converged starts by that original objective, before hard least-squares refit.
If no start converges, the diagnostic representative minimizes the sum of
scaled primal and dual residuals; it remains invalid. The refit generator state
of the selected start is saved and restored, so deferring refit does not
change its random starts.

For a nominal budget S, use 1 PCA start, max(1,floor(S/4)) random starts for
S>1, and the remaining starts as rotated PCA. The base order is PCA, all
rotated PCA, all random. A continuation warm start runs first and **replaces
the last rotation** (or last base start if no rotation exists); it does not
increase the budget. Retained base starts keep their original semantic seeds.

| Stage | Total starts | Without warm start | Outer cap | Smooth inner cap |
| --- | ---: | --- | ---: | ---: |
| Simulation tuning | 3 | 1 PCA + 1 rotated + 1 random | 120 | 18 |
| Failed tuning candidate retry | 6 | 1 PCA + 4 rotated + 1 random | 240 | 18 |
| All-candidates-failed emergency | 6 | same 6-start bank | 480 | 18 |
| Simulation final fit | 8 | 1 PCA + 5 rotated + 2 random | 120 | 25 |
| Failed final fit retry | 12 | 1 PCA + 8 rotated + 3 random | 240 | 25 |

Centers have at most 12 inner updates, movement tolerance 1e-9, and a
nonincrease safeguard of 1e-12 times max(1,abs(previous center loss)). The
smooth-block stopping rule is mean((L_new-L_old)^2) +
mean((F_new-F_old)^2) < 1e-9 (not a relative-change criterion).
Discovery termination requires all of:

- ||L-Theta||_F/sqrt(Nr) < 2e-5;
- ||kappa(Theta-Theta_old)||_F/(kappa sqrt(Nr)) < 2e-5;
- abs(objective_old-objective)/max(1,abs(objective)) < 1e-7.

At termination, labels are assigned from Theta to its nearest centers, unused
centers are removed, and each sorted active center c merges into the last
retained center if their distance is <= 1e-8 times max(1,abs(c)).
Active labels are made contiguous before
refit. Tolerances are unchanged in retry stages.

## 4. Simulation tuning and failure recovery

Use the first floor(0.8T) columns for training (48 or 96); validation is the
remaining 12 or 24. The generic function additionally clamps training to at
least 20 and leaves at least 10 validation columns. The ordered penalty ratios
are (0.25,0.5,1,2,4), with alpha_train=ratio sqrt(T_train).

1. Draw one three-start seed bank and one warm seed, shared by all five alpha
   values. Visit alpha in ascending order. Continue from the most recent
   converged lower-alpha **refitted** training solution when available.
2. Retry only nonconverged alpha candidates with a newly drawn six-start bank,
   shared across these retries, 240 iterations and kappa/T_train=1. Use the
   nearest converged lower alpha for continuation when available.
3. Only when **none** of the five final candidates converges, enter emergency
   recovery. Visit all alpha values in ascending order; reuse the six-start
   retry bank and try kappa/T_train=1,2,4 in that order at 480 iterations.
   Stop changing kappa at the first successful fit for that alpha. Continue
   evaluating subsequent alpha values. Do not run this tier on an already
   valid replication merely to improve its score.
4. Among converged candidates, select the smallest validation reconstruction
   MSE (ascending-alpha order resolves an exact tie). Transfer the ratio to
   the full sample: alpha_full=alpha_train sqrt(T/T_train).

Validation solves A=argmin_A ||X_val-L_train A||_F^2 by
`np.linalg.lstsq(...,rcond=None)` and returns the mean of the squared residual
entries. Validation factors are estimated contemporaneously. No future-factor
forecasting model is used. K and alpha are selected using validation error;
model fitting and start ranking at each candidate use training data only.

For the final simulation fit, pre-generate 12 start seeds and use the first
eight with the eight-start allocation. If invalid, rerun with all 12 and the
12-start allocation at 240 iterations, kappa/T=1. If still invalid, retry
kappa/T=2, then 4 with the same 12 seeds and 240 cap, returning the first
converged tier. Changing eight to twelve changes the start types at some
seed positions: it is **not** eight identical starts plus four new starts.
No training warm start is added to this final simulation search.

## 5. PCA–KM, Oracle–FS, and common hard refit

PCA–KM first obtains the uncentered PCA loadings, then applies one-dimensional
squared-error k-means to each column. Each column uses 12 initializations:
one at NumPy's linear quantiles (g+0.5)/K, g=0,...,K-1, followed by 11 samples
of K observation entries without replacement. Each Lloyd run is capped at
80 updates and stops at maximum center movement <1e-10. Centers are sorted
after updates. During an update an empty center is placed at the observation
with greatest current squared loss. At termination, each empty group is
filled by moving the worst represented observation from a group of size >1;
centers are then recomputed and sorted. Select the lowest within-column SSE,
retaining the first exact tie. The default of the helper alone is not the
benchmark setting: `pca_kmeans_estimator` explicitly passes **12** starts.

MDSP's selected labels, PCA–KM's labels, and Oracle–FS's true labels all use
`factor_specific_refit`. This is fixed-membership constrained least squares:
8 starts (PCA factors plus 7 T by r Gaussian-QR factor starts), at most 100
alternations. With F fixed, update each coordinate's centers by least squares;
with L fixed, update F by the normalized orthogonal Procrustes solution.
Stop when abs(RSS_old-RSS)/max(1,abs(RSS)) <1e-10. Return the minimum-RSS
start; exact ties retain the first start. Memberships stay fixed throughout.
Oracle–FS knows true memberships but estimates centers and factors with this
same numerical refit. No global minimum certificate or additional independent
refit-convergence screen is claimed.

## 6. Metrics and reporting

L-RMSE and F-RMSE use sign/permutation alignment. Factor permutations are
restricted to compatible group-count coordinates and chosen by maximum summed
absolute loading cosine. No arbitrary rotation is allowed to remove the
orientation error. C-RE is ||Lhat Fhat'-L F'||_F/||L F'||_F.

Within each aligned coordinate, group labels are matched by optimal one-to-one
assignment; numeric group names carry no meaning. MCR and ARI are coordinate
averages. Exact is one only when **every observation in every coordinate** is
correct after matching and active group counts agree; otherwise it is zero.
MDSP's end-to-end Exact also assigns zero to numerical failures. Table/figure
Exact values average this Bernoulli outcome across 200 replications. No Monte
Carlo standard error is printed for Exact in the manuscript display, although
its sampling variance exists. Other parentheses in simulation tables are
Monte Carlo standard errors (sample SD, ddof=1, divided by sqrt(B)).

## 7. Two-factor group-count diagnostic (Table 4)

Use N=T=60, r=2, B=100, master seed 20260918, balanced four profiles with
centers (+/-1.1),(+/-0.9). The factor/error construction follows the same
non-demeaned normalized AR-factor and cross-correlated Gaussian-error scheme.
Search only K=(2,2),(3,3),(4,4), with the simulation alpha path above. This
diagnostic covers correct and oversized K, not underspecified K. The
validation tolerance rules are 0%, 0.5%, 1%, 2%; the main display retains
minimum CV and 1% plus fixed-(2,2) and fixed-(4,4). The other rules remain in
the diagnostic's newly generated output. Parsimony minimizes active scalar centers among eligible
training candidates; truth is used only for evaluation. Exact implementation,
tie keys, and streams are frozen in
`group_count_selection.py` and `run_group_count_sensitivity.py`.
For replication b (zero-based), data use SeedSequence([20260918,b,0]); the
tuning generator uses [20260918,b,1] and draws one integer seed that is reset
for every K, giving a common tuning stream across K. Final fits use
SeedSequence([20260918,b,2,*K,round(100*ratio)]) and are cached within a
replication so reporting rules selecting the same K/ratio reuse the same fit.

