"""Run the two-factor group-count diagnostic directly from its data generator."""
import argparse
import subprocess
import sys
from pathlib import Path
from common import ROOT, fresh_directory, check_core
import simulation_study as s

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--replications',type=int,default=100)
    p.add_argument('--workers',type=int,default=4)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args()
    if a.replications<1 or a.workers<1:p.error('replications and workers must be positive')
    check_core(s);out=fresh_directory(a.output)
    subprocess.run([sys.executable,'-B',str(ROOT/'run_group_count_sensitivity.py'),
        '--replications',str(a.replications),'--workers',str(a.workers),'--out',str(out)],check=True)
