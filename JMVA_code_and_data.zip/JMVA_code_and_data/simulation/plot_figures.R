# Portable base-R rendering. First run make_tables.py.
args <- commandArgs(trailingOnly=TRUE)
if (length(args) != 2) stop('Usage: Rscript plot_figures.R TABLE_DIRECTORY OUTPUT_DIRECTORY')
if (dir.exists(args[2]) && length(list.files(args[2],all.files=TRUE,no..=TRUE))) stop('Output directory must be new or empty')
dir.create(args[2], recursive=TRUE, showWarnings=FALSE)
# Native R devices only. PDF text remains editable; PNG is a convenience export.
open_figure <- function(name, width, height) {
  prefix <<- file.path(args[2], name); figure_width <<- width; figure_height <<- height
  measured_panels <<- character()
  if (identical(Sys.getenv('JMVA_CAIRO'),'1')) {
    cairo_pdf(paste0(prefix,'.pdf'),width=width,height=height,family='Helvetica',pointsize=12,bg='white')
  } else {
    pdf(paste0(prefix,'.pdf'),width=width,height=height,family='Helvetica',pointsize=12,useDingbats=FALSE,bg='white')
  }
  dev.control(displaylist='enable')
}
measure_panel <- function(id, row, col) {
  u <- par('usr'); xx <- sort(grconvertX(u[1:2], 'user', 'ndc'))*figure_width*72
  yy <- sort(grconvertY(u[3:4], 'user', 'ndc'))*figure_height*72
  measured_panels <<- c(measured_panels, sprintf('{"id":"%s","bbox_pt":[%.8f,%.8f,%.8f,%.8f],"grid_id":"main","row_start":%d,"row_stop":%d,"col_start":%d,"col_stop":%d}',id,xx[1],yy[1],xx[2],yy[2],row,row+1,col,col+1))
}
close_figure <- function() {
  snapshot <- recordPlot()
  manifest <- sprintf('{"schema_version":1,"backend":"base-R","figure":{"width_pt":%.8f,"height_pt":%.8f},"panels":[%s]}',figure_width*72,figure_height*72,paste(measured_panels,collapse=','))
  writeLines(manifest,paste0(prefix,'.alignment-layout.json'))
  dev.off()
  # Optional SVG needs a working Cairo library; it is not required for PDF replication.
  if (identical(Sys.getenv('JMVA_EXPORT_SVG'),'1')) {
    svg(paste0(prefix,'.svg'),width=figure_width,height=figure_height,family='Helvetica');replayPlot(snapshot);dev.off()
  }
  bitmap_type <- if(Sys.info()[['sysname']]=='Darwin') 'quartz' else 'cairo'
  png(paste0(prefix,'.png'),width=figure_width,height=figure_height,units='in',res=300,type=bitmap_type,bg='white');replayPlot(snapshot);dev.off()
}
r <- read.csv(file.path(args[1], 'figure_2_data.csv'))
stopifnot(nrow(r)==72, all(is.finite(r$population_pca_rotation_degrees)), all(r$exact>=0 & r$exact<=1))
open_figure('figure_2_orientation_exact',7.2,5.3)
par(mfrow=c(2,2), mar=c(3.3,3.7,2.1,0.6), oma=c(1,0,1.2,0), mgp=c(2.2,.6,0), tcl=-.25, cex=.88)
dims <- rbind(c(60,60),c(60,120),c(120,60),c(120,120))
for (j in 1:4) {
 a <- r[r$N==dims[j,1] & r$T==dims[j,2] & grepl('^pca_orientation_',r$scenario),]
 plot(NA,xlim=c(0,40),ylim=c(-.025,1.025),xlab='Realized PCA rotation angle (degrees)',ylab='Exact recovery frequency',axes=FALSE)
 rect(35.70,-.025,40,1.025,col='#F2F2F2',border=NA)
 abline(h=seq(0,1,.2),col='#E3E3E3',lwd=.6)
 axis(1,at=seq(0,40,10));axis(2,at=seq(0,1,.2),las=1);box(col='#666666')
 for(m in c('PCA-KM','MDSP')) {
  b <- a[a$method==m,]; b<-b[order(b$population_pca_rotation_degrees),]
  y <- if(m=='MDSP') b$end_to_end_exact else b$exact
  lines(b$population_pca_rotation_degrees,y,col=if(m=='MDSP') '#0072B2' else '#D55E00',lty=if(m=='MDSP') 1 else 2,lwd=1.8)
  points(b$population_pca_rotation_degrees,y,col=if(m=='MDSP') '#0072B2' else '#D55E00',pch=if(m=='MDSP') 1 else 17,cex=.85,lwd=1.2)
 }
 title(main=sprintf('(%s)  N = %d, T = %d',letters[j],dims[j,1],dims[j,2]),adj=0,cex.main=1)
 if(j==1) legend('bottomleft',c('PCA-KM','MDSP'),col=c('#D55E00','#0072B2'),lty=c(2,1),pch=c(17,1),bty='n',cex=.9)
 measure_panel(letters[j],(j-1)%/%2,(j-1)%%2)
}
close_figure()

