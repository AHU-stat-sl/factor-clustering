"""Unit tests for the V2 Monte Carlo implementation."""

from __future__ import annotations

import itertools
import math
import sys
import unittest
from pathlib import Path
from unittest import mock

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))

import simulation_study as simulation


class SimulationStudyTests(unittest.TestCase):
    def test_exact_kmedians_matches_brute_force(self) -> None:
        rng = np.random.default_rng(7)
        for n in range(2, 9):
            values = rng.normal(size=n)
            ordered = np.sort(values)
            for groups in range(1, min(4, n + 1)):
                _, _, objective = simulation.exact_kmedians_1d(values, groups)
                brute_force = math_inf = float("inf")
                for cuts in itertools.combinations(range(1, n), groups - 1):
                    bounds = (0, *cuts, n)
                    candidate = sum(
                        np.abs(
                            ordered[bounds[j] : bounds[j + 1]]
                            - np.median(ordered[bounds[j] : bounds[j + 1]])
                        ).sum()
                        for j in range(groups)
                    )
                    brute_force = min(brute_force, float(candidate))
                self.assertNotEqual(brute_force, math_inf)
                self.assertAlmostEqual(objective, brute_force, places=11)

    def test_vectorized_kmedians_preserves_reference_tie_breaking(self) -> None:
        def reference(values: np.ndarray, groups: int):
            sample = np.asarray(values, dtype=float).reshape(-1)
            n = sample.size
            order = np.argsort(sample, kind="stable")
            ordered = sample[order]
            prefix = np.concatenate(([0.0], np.cumsum(ordered)))
            starts = np.arange(n)[:, None]
            ends = np.arange(n)[None, :]
            medians = (starts + ends) // 2
            centers_by_segment = ordered[medians]
            left_cost = centers_by_segment * (medians - starts) - (
                prefix[medians] - prefix[starts]
            )
            right_cost = (
                prefix[ends + 1]
                - prefix[medians + 1]
                - centers_by_segment * (ends - medians)
            )
            cost = np.where(
                starts <= ends,
                left_cost + right_cost,
                math.inf,
            )
            dynamic = np.full((groups + 1, n + 1), math.inf)
            previous = np.full((groups + 1, n + 1), -1, dtype=int)
            dynamic[0, 0] = 0.0
            for group in range(1, groups + 1):
                for end in range(group, n + 1):
                    splits = np.arange(group - 1, end)
                    candidates = dynamic[group - 1, splits] + cost[splits, end - 1]
                    best = int(np.argmin(candidates))
                    previous[group, end] = int(splits[best])
                    dynamic[group, end] = float(candidates[best])
            ordered_labels = np.empty(n, dtype=int)
            centers = np.empty(groups)
            end = n
            for group in range(groups, 0, -1):
                start = previous[group, end]
                ordered_labels[start:end] = group - 1
                centers[group - 1] = ordered[(start + end - 1) // 2]
                end = start
            labels = np.empty(n, dtype=int)
            labels[order] = ordered_labels
            return centers, labels, float(dynamic[groups, n])

        rng = np.random.default_rng(9)
        for n in range(2, 25):
            values = np.round(rng.normal(size=n), 1)
            for groups in range(1, min(5, n) + 1):
                expected = reference(values, groups)
                actual = simulation.exact_kmedians_1d(values, groups)
                np.testing.assert_array_equal(actual[0], expected[0])
                np.testing.assert_array_equal(actual[1], expected[1])
                self.assertAlmostEqual(actual[2], expected[2], places=11)

    def test_generated_factors_are_normalized(self) -> None:
        panel = simulation.generate_panel(
            24, 40, "baseline", np.random.default_rng(11)
        )
        gram = panel.factors.T @ panel.factors / panel.factors.shape[0]
        np.testing.assert_allclose(gram, np.eye(3), atol=1e-12)

    def test_baseline_has_all_twelve_profiles(self) -> None:
        panel = simulation.generate_panel(
            60, 60, "baseline", np.random.default_rng(13)
        )
        self.assertEqual(len(np.unique(panel.profiles)), 12)

    def test_aligned_design_remains_full_rank(self) -> None:
        panel = simulation.generate_panel(
            60, 60, "aligned_boundary", np.random.default_rng(17)
        )
        self.assertEqual(np.linalg.matrix_rank(panel.loadings), 3)
        self.assertFalse(panel.orientation_identified)

    def test_collapse_removes_inactive_and_coincident_centers(self) -> None:
        theta = np.array([0.0, 0.0, 2.0, 2.0])
        centers = np.array([0.0, 0.0, 2.0, 9.0])
        active, labels = simulation.collapse_active_centers(theta, centers, 1e-8)
        np.testing.assert_allclose(active, [0.0, 2.0])
        np.testing.assert_array_equal(labels, [0, 0, 1, 1])

    def test_alignment_respects_group_count_equivalence(self) -> None:
        truth = np.eye(3)
        estimated = truth[:, [0, 2, 1]]
        _, _, permutation, _ = simulation.best_alignment(
            estimated,
            estimated,
            truth,
            truth,
            (2, 3, 2),
        )
        self.assertEqual(permutation[1], 1)
        self.assertIn(permutation, {(0, 1, 2), (2, 1, 0)})

    def test_start_allocation_keeps_pca_and_adds_warm(self) -> None:
        self.assertEqual(
            simulation.start_allocation(8),
            {"warm": 0, "pca": 1, "rotated_pca": 5, "random": 2},
        )
        self.assertEqual(
            simulation.start_allocation(8, has_warm=True),
            {"warm": 1, "pca": 1, "rotated_pca": 4, "random": 2},
        )

    def test_warm_start_preserves_total_start_budget(self) -> None:
        for starts in (3, 6, 8):
            allocation = simulation.start_allocation(starts, has_warm=True)
            self.assertEqual(sum(allocation.values()), starts)

    def test_multistart_refits_only_the_selected_discovery(self) -> None:
        rng = np.random.default_rng(27)
        x = rng.normal(size=(12, 20))
        with mock.patch.object(
            simulation,
            "factor_specific_refit",
            wraps=simulation.factor_specific_refit,
        ) as refit:
            result = simulation.mdsp_multistart(
                x,
                (2, 2),
                alpha=1.0,
                rng=np.random.default_rng(29),
                starts=3,
                max_outer=2,
                max_inner=1,
                start_seeds=(31, 37, 41),
            )
        self.assertEqual(refit.call_count, 1)
        self.assertNotIn("_refit_rng_state", result[4])

    def test_named_suites_do_not_duplicate_designs(self) -> None:
        for suite in (
            "structure",
            "separation",
            "stress",
            "scaling",
            "orientation_stress",
            "publication",
        ):
            designs = simulation.publication_designs(suite)
            self.assertEqual(len(designs), len(set(designs)))

    def test_parse_dimensions(self) -> None:
        self.assertEqual(
            simulation.parse_dimensions("60x60, 60X120,120x60,120x120"),
            [(60, 60), (60, 120), (120, 60), (120, 120)],
        )
        for invalid in ("", "60", "60x", "0x60", "60x60,60x60"):
            with self.assertRaises(ValueError):
                simulation.parse_dimensions(invalid)

    def test_scaling_suite_has_requested_sizes_and_designs(self) -> None:
        self.assertEqual(
            simulation.publication_designs("scaling"),
            [
                (60, 60, "partial"),
                (120, 120, "partial"),
                (240, 240, "partial"),
                (60, 60, "unbalanced"),
                (120, 120, "unbalanced"),
                (240, 240, "unbalanced"),
            ],
        )

    def test_pca_orientation_stress_has_exact_controlled_gram(self) -> None:
        scenarios = {
            "pca_orientation_rho_0": 0.0,
            "pca_orientation_rho_10": 0.1,
            "pca_orientation_rho_20": 0.2,
            "pca_orientation_rho_30": 0.3,
            "pca_orientation_rho_40": 0.4,
            "pca_orientation_rho_50": 0.5,
            "pca_orientation_rho_60": 0.6,
            "pca_orientation_rho_70": 0.7,
            "pca_orientation_rho_80": 0.8,
        }
        for scenario, rho in scenarios.items():
            panel = simulation.generate_panel(
                120, 120, scenario, np.random.default_rng(101)
            )
            self.assertEqual(panel.group_counts, (2, 2, 2))
            self.assertEqual(len(np.unique(panel.profiles)), 8)
            for factor in range(3):
                np.testing.assert_array_equal(
                    np.bincount(panel.labels[:, factor]), [60, 60]
                )
            expected_gram = np.array(
                [
                    [1.21, 0.99 * rho, 0.0],
                    [0.99 * rho, 0.81, 0.0],
                    [0.0, 0.0, 0.36],
                ]
            )
            np.testing.assert_allclose(
                panel.loadings.T @ panel.loadings / 120,
                expected_gram,
                atol=1e-14,
            )
            expected_angle = math.degrees(
                0.5 * math.atan2(1.98 * rho, 1.21 - 0.81)
            )
            self.assertAlmostEqual(
                panel.diagnostics["population_pca_rotation_degrees"],
                expected_angle,
                places=12,
            )
            self.assertAlmostEqual(
                panel.diagnostics["pca_orientation_target_rho"], rho, places=12
            )
            self.assertAlmostEqual(
                panel.diagnostics["pca_orientation_rho"], rho, places=12
            )

    def test_n60_orientation_stress_reports_realized_rho(self) -> None:
        for target in np.arange(0.0, 0.9, 0.1):
            scenario = f"pca_orientation_rho_{int(round(100 * target))}"
            panel = simulation.generate_panel(
                60, 60, scenario, np.random.default_rng(103)
            )
            realized = float(panel.diagnostics["pca_orientation_rho"])
            self.assertAlmostEqual(
                panel.diagnostics["pca_orientation_target_rho"], target, places=12
            )
            self.assertLessEqual(abs(realized - target), 1.0 / 30.0 + 1e-12)
            for factor in range(3):
                np.testing.assert_array_equal(
                    np.bincount(panel.labels[:, factor]), [30, 30]
                )
            expected_gram = np.array(
                [
                    [1.21, 0.99 * realized, 0.0],
                    [0.99 * realized, 0.81, 0.0],
                    [0.0, 0.0, 0.36],
                ]
            )
            np.testing.assert_allclose(
                panel.loadings.T @ panel.loadings / 60,
                expected_gram,
                atol=1e-14,
            )

    def test_orientation_stress_suite_has_requested_rho_path(self) -> None:
        self.assertEqual(
            simulation.publication_designs("orientation_stress"),
            [
                (120, 120, "pca_orientation_rho_0"),
                (120, 120, "pca_orientation_rho_10"),
                (120, 120, "pca_orientation_rho_20"),
                (120, 120, "pca_orientation_rho_30"),
                (120, 120, "pca_orientation_rho_40"),
                (120, 120, "pca_orientation_rho_50"),
                (120, 120, "pca_orientation_rho_60"),
                (120, 120, "pca_orientation_rho_70"),
                (120, 120, "pca_orientation_rho_80"),
            ],
        )

    def test_lstsq_validation_handles_rank_deficiency(self) -> None:
        loadings = np.array([[1.0, 1.0], [2.0, 2.0], [3.0, 3.0]])
        validation = np.array([[1.0, 2.0], [2.0, 4.0], [3.0, 6.0]])
        self.assertAlmostEqual(
            simulation.validation_mse(loadings, validation), 0.0, places=12
        )

    def test_method_rng_consumption_is_isolated(self) -> None:
        _, streams_a = simulation.replication_rngs(23)
        _, streams_b = simulation.replication_rngs(23)
        streams_a["pca_kmeans"].random(100)
        self.assertEqual(streams_a["mdsp"].random(), streams_b["mdsp"].random())

    def test_run_task_preserves_run_one_arguments(self) -> None:
        task = (4, 5, "baseline", 23, False, 8)
        sentinel = [{"method": "sentinel"}]
        with mock.patch.object(simulation, "run_one", return_value=sentinel) as run_one:
            self.assertIs(simulation.run_task(task), sentinel)
        run_one.assert_called_once_with(*task)

    def test_full_sample_retry_reuses_initial_seeds_and_expands_budget(self) -> None:
        calls = []

        def fake_multistart(x, group_counts, alpha, rng, **kwargs):
            calls.append(kwargs)
            converged = kwargs["starts"] == simulation.CONFIG.final_retry_starts
            loadings = np.ones((x.shape[0], 1))
            factors = np.ones((x.shape[1], 1))
            labels = np.zeros((x.shape[0], 1), dtype=int)
            diagnostics = {
                "converged": int(converged),
                "failure_reason": "" if converged else "primal_not_converged",
                "scaled_primal": 0.0 if converged else 1.0,
                "scaled_dual": 0.0,
                "relative_objective_change": 0.0,
                "iterations": kwargs["max_outer"],
                "converged_starts": int(converged),
            }
            return loadings, factors, labels, 0.0, diagnostics

        with mock.patch.object(
            simulation, "mdsp_multistart", side_effect=fake_multistart
        ):
            result = simulation.mdsp_full_sample_with_retry(
                np.ones((4, 5)),
                (1,),
                1.0,
                np.random.default_rng(37),
            )

        self.assertEqual(len(calls), 2)
        self.assertEqual(calls[0]["starts"], 8)
        self.assertEqual(calls[0]["max_outer"], 120)
        self.assertEqual(calls[1]["starts"], 12)
        self.assertEqual(calls[1]["max_outer"], 240)
        self.assertEqual(calls[0]["start_seeds"], calls[1]["start_seeds"][:8])
        self.assertEqual(result[4]["final_fit_retried"], 1)
        self.assertEqual(result[4]["retry_recovered"], 1)

    def test_full_sample_retry_is_skipped_after_initial_convergence(self) -> None:
        calls = []

        def converged_multistart(x, group_counts, alpha, rng, **kwargs):
            calls.append(kwargs)
            loadings = np.ones((x.shape[0], 1))
            factors = np.ones((x.shape[1], 1))
            labels = np.zeros((x.shape[0], 1), dtype=int)
            diagnostics = {
                "converged": 1,
                "failure_reason": "",
                "scaled_primal": 0.0,
                "scaled_dual": 0.0,
                "relative_objective_change": 0.0,
                "iterations": 20,
                "converged_starts": 1,
            }
            return loadings, factors, labels, 0.0, diagnostics

        with mock.patch.object(
            simulation, "mdsp_multistart", side_effect=converged_multistart
        ):
            result = simulation.mdsp_full_sample_with_retry(
                np.ones((4, 5)),
                (1,),
                1.0,
                np.random.default_rng(41),
            )

        self.assertEqual(len(calls), 1)
        self.assertEqual(result[4]["final_fit_retried"], 0)
        self.assertEqual(result[4]["final_fit_attempt"], 1)

    def test_full_sample_retry_uses_penalty_grid_only_after_base_retry_fails(self) -> None:
        calls = []

        def fake_multistart(x, group_counts, alpha, rng, **kwargs):
            calls.append(kwargs)
            converged = kwargs["kappa_over_t"] == 2.0
            loadings = np.ones((x.shape[0], 1))
            factors = np.ones((x.shape[1], 1))
            labels = np.zeros((x.shape[0], 1), dtype=int)
            diagnostics = {
                "converged": int(converged),
                "failure_reason": "" if converged else "primal_not_converged",
                "scaled_primal": 0.0 if converged else 1.0,
                "scaled_dual": 0.0,
                "relative_objective_change": 0.0,
                "iterations": kwargs["max_outer"],
                "converged_starts": int(converged),
                "kappa_over_t": kwargs["kappa_over_t"],
            }
            return loadings, factors, labels, 0.0, diagnostics

        with mock.patch.object(
            simulation, "mdsp_multistart", side_effect=fake_multistart
        ):
            result = simulation.mdsp_full_sample_with_retry(
                np.ones((4, 5)),
                (1,),
                1.0,
                np.random.default_rng(43),
            )

        self.assertEqual([call["kappa_over_t"] for call in calls], [1.0, 1.0, 2.0])
        self.assertEqual(calls[1]["start_seeds"], calls[2]["start_seeds"])
        self.assertEqual(result[4]["final_fit_attempt"], 3)
        self.assertEqual(result[4]["retry_recovered"], 1)

    def test_factor_and_group_diagnostics(self) -> None:
        true_labels = np.array(
            [
                [0, 0, 0],
                [0, 0, 0],
                [0, 1, 0],
                [1, 1, 1],
                [1, 2, 1],
                [1, 2, 1],
            ]
        )
        estimated_labels = true_labels.copy()
        estimated_labels[4, 1] = 1
        true_loadings = np.array(
            [
                [-1.0, -1.0, -0.5],
                [-1.0, -1.0, -0.5],
                [-1.0, 0.0, -0.5],
                [1.0, 0.0, 0.5],
                [1.0, 1.0, 0.5],
                [1.0, 1.0, 0.5],
            ]
        )
        true_factors = np.eye(3)
        result = simulation.metrics(
            true_loadings,
            true_factors,
            estimated_labels,
            true_loadings,
            true_factors,
            true_labels,
            simulation.profile_codes(true_labels),
            (2, 3, 2),
        )
        self.assertAlmostEqual(result["factor_2_mcr"], 1.0 / 6.0)
        self.assertAlmostEqual(result["factor_2_group_3_recall"], 0.5)
        self.assertEqual(result["factor_2_group_3_estimated_size"], 1)
        self.assertAlmostEqual(result["factor_2_alignment_cosine"], 1.0)

    def test_validation_retries_only_failed_alpha_with_shared_seed_bank(self) -> None:
        calls: list[tuple[float, int]] = []

        def fake_multistart(x, group_counts, alpha, rng, **kwargs):
            starts = kwargs["starts"]
            calls.append((alpha, starts))
            converged = starts == simulation.CONFIG.cv_retry_starts or alpha > 2.0
            loadings = np.ones((x.shape[0], 1))
            factors = np.ones((x.shape[1], 1))
            labels = np.zeros((x.shape[0], 1), dtype=int)
            diagnostics = {
                "converged": int(converged),
                "failure_reason": "" if converged else "primal_not_converged",
                "attempted_starts": starts,
                "converged_starts": int(converged),
                "start_allocation": "{}",
                "active_group_counts": ",".join(map(str, group_counts)),
                "scaled_primal": 0.0 if converged else 1.0,
                "scaled_dual": 0.0,
            }
            return loadings, factors, labels, 0.0, diagnostics

        x = np.arange(120.0).reshape(3, 40)
        with mock.patch.object(
            simulation, "mdsp_multistart", side_effect=fake_multistart
        ) as fitted:
            alpha, records = simulation.validation_alpha(
                x,
                (1,),
                np.random.default_rng(29),
                return_diagnostics=True,
                grid_ratios=(0.25, 0.50),
            )

        self.assertIsNotNone(alpha)
        self.assertEqual(len(calls), 3)
        self.assertEqual(sum(row["tuning_attempt"] == 2 for row in records), 1)
        self.assertEqual(
            fitted.call_args_list[0].kwargs["start_seeds"],
            fitted.call_args_list[1].kwargs["start_seeds"],
        )

    def test_validation_does_not_fallback_when_every_alpha_fails(self) -> None:
        def failed_multistart(x, group_counts, alpha, rng, **kwargs):
            loadings = np.ones((x.shape[0], 1))
            factors = np.ones((x.shape[1], 1))
            labels = np.zeros((x.shape[0], 1), dtype=int)
            diagnostics = {
                "converged": 0,
                "failure_reason": "primal_not_converged",
                "attempted_starts": kwargs["starts"],
                "converged_starts": 0,
                "start_allocation": "{}",
                "active_group_counts": ",".join(map(str, group_counts)),
                "scaled_primal": 1.0,
                "scaled_dual": 0.0,
            }
            return loadings, factors, labels, 0.0, diagnostics

        x = np.arange(120.0).reshape(3, 40)
        with mock.patch.object(
            simulation, "mdsp_multistart", side_effect=failed_multistart
        ):
            alpha, records = simulation.validation_alpha(
                x,
                (1,),
                np.random.default_rng(31),
                return_diagnostics=True,
                grid_ratios=(0.25, 0.50),
            )

        self.assertIsNone(alpha)
        self.assertEqual(len(records), 10)
        self.assertEqual(
            [row["kappa_over_t"] for row in records[-3:]],
            [1.0, 2.0, 4.0],
        )
        self.assertFalse(any(row["selected"] for row in records))

    def test_end_to_end_exact_uses_all_replications(self) -> None:
        rows = [
            {
                "scenario": "baseline",
                "N": 20,
                "T": 20,
                "method": "MDSP",
                "group_counts": "2,3,2",
                "structure": "crossed",
                "exact": 1.0,
                "end_to_end_exact": 1.0,
                "statistical_fit_valid": 1,
            },
            {
                "scenario": "baseline",
                "N": 20,
                "T": 20,
                "method": "MDSP",
                "group_counts": "2,3,2",
                "structure": "crossed",
                "exact": float("nan"),
                "end_to_end_exact": 0.0,
                "statistical_fit_valid": 0,
            },
        ]
        summary = simulation.summarize(rows)[0]
        self.assertEqual(summary["n_exact"], 1)
        self.assertEqual(summary["exact"], 1.0)
        self.assertEqual(summary["n_end_to_end_exact"], 2)
        self.assertEqual(summary["end_to_end_exact"], 0.5)


if __name__ == "__main__":
    unittest.main()
