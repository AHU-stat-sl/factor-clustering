# Simulations

Self-contained implementation of the manuscript simulations. This folder ships
code, fixed settings and input seeds only. Every numerical output is generated
by running the code; no previous estimates are loaded.

## Setup

Use Python 3.12 (tested with 3.12.14):

```sh
python3.12 -m venv .venv
source .venv/bin/activate
# Windows activation: .venv\Scripts\activate
python -m pip install -r requirements.txt
```

Run the following commands from this folder. BLAS threads are limited to one
per worker by the launchers. Use a new or empty output directory each time.

## Quick execution checks

```sh
python -m unittest discover -s . -p 'test_*.py'
python run_simulations.py --mode smoke --workers 2 --output outputs/smoke
python run_group_counts.py --replications 2 --workers 2 --output outputs/group_count_smoke
```

The core smoke run computes five panels, including two cases exercising the
numerical-recovery path. It is not the full Monte Carlo. Replication-level
convergence diagnostics and failures are recorded in the newly generated CSVs.

## Full manuscript calculations

```sh
python run_simulations.py --mode full --workers 4 --output outputs/core
python run_group_counts.py --replications 100 --workers 4 --output outputs/group_counts
python make_tables.py --core outputs/core/summary.csv --group-counts outputs/group_counts/summary.csv --output outputs/tables
Rscript plot_figures.R outputs/tables outputs/figures
```

The core has 8,800 panels: baseline, partial sharing and nine orientation-stress
settings, each at N,T in {60,120} with 200 replications. All use r=3. The separate
group-count diagnostic uses r=2, N=T=60 and 100 replications. Table formatting
requires all core cells, so the five-panel smoke output is insufficient for it.

`simulation_study.py` is the unchanged numerical engine; its auxiliary designs
remain available but are not run by the manuscript launcher. The three grouped
methods use the same eight-start fixed-membership refit. Initialization,
continuation and failure recovery are specified in `NUMERICAL_PROTOCOL.md` and
`configs/protocol.json`. `configs/core_tasks.csv` is the original **input seed
plan**, not old result data. Keep its seeds unchanged when reproducing the study.

The plot script writes editable-text PDF and PNG using base R. Optional
`JMVA_CAIRO=1` or `JMVA_EXPORT_SVG=1` requires working Cairo devices. Numerical
results can vary with BLAS/LAPACK builds; fixed seeds do not ensure bitwise
cross-platform identity. Convergence does not certify a global optimum.
