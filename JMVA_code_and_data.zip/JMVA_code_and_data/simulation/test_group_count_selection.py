import unittest
from group_count_selection import select_candidate


def row(k,active,score,converged=1,final=1):
    return dict(group_counts=k,active_group_counts=active,validation_mse=score,
                converged=converged,final_candidate=final,alpha_over_sqrt_train=1)

class SelectorTests(unittest.TestCase):
    def test_parsimony_only_inside_tolerance(self):
        rich=row((4,4),'4,4',1); lean=row((2,2),'2,2',1.009)
        too_poor=row((1,1),'1,1',1.02)
        self.assertIs(select_candidate([rich,lean,too_poor]),lean)
        self.assertIs(select_candidate([rich,lean],0),rich)
    def test_active_not_requested_budget(self):
        collapsed=row((4,4),'2,2',1.005); richer=row((3,3),'3,3',1)
        self.assertIs(select_candidate([collapsed,richer]),collapsed)
    def test_invalid_and_superseded_are_excluded(self):
        good=row((3,3),'3,3',1)
        self.assertIs(select_candidate([row((2,2),'2,2',.5,0),row((2,2),'2,2',.6,1,0),good]),good)
        self.assertIsNone(select_candidate([]))
    def test_order_independent_ties(self):
        a=row((2,2),'2,2',1);b=row((4,4),'2,2',1)
        self.assertIs(select_candidate([b,a]),a)
        self.assertIs(select_candidate([a,b]),a)
    def test_tolerance_validation(self):
        for delta in [-1,float('nan')]:
            with self.assertRaises(ValueError):select_candidate([],delta)
if __name__=='__main__':unittest.main()
