"""Format Tables 1-4 and Figure 2 input from newly generated simulation CSVs."""
import argparse
from collections import Counter
from pathlib import Path
from common import ROOT, readcsv, writecsv, fresh_directory

def cell(r,key,digits=3):
    return f'{float(r[key]):.{digits}f} ({float(r["se_"+key]):.4f})'

def exact(r):
    if r['method'] in ('PCA','Oracle-FS'):return '—'
    return f'{float(r["end_to_end_exact"] if r["method"]=="MDSP" else r["exact"]):.3f}'

def recovery(r):
    return dict(**{'C-RE':cell(r,'common_re')},MCR='—' if r['method']=='Oracle-FS' else cell(r,'mcr',4),
                ARI='—' if r['method']=='Oracle-FS' else cell(r,'ari'),Exact=exact(r))

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--core',type=Path,required=True,help='summary.csv from a full core run')
    p.add_argument('--group-counts',type=Path,required=True,help='summary.csv from the group-count diagnostic')
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();out=fresh_directory(a.output)
    rows=readcsv(a.core);lookup={(r['scenario'],int(r['N']),int(r['T']),r['method']):r for r in rows}
    tables={};dims=[(60,60),(60,120),(120,60),(120,120)]
    table=[]
    for n,t in dims:
        for method in ('PCA','PCA-KM','MDSP','Oracle-FS'):
            r=lookup['baseline',n,t,method]
            table.append(dict(N=n,T=t,Method=method,**{'L-RMSE':cell(r,'loading_rmse'),'F-RMSE':cell(r,'factor_rmse'),'C-RE':cell(r,'common_re')},Exact=exact(r)))
    tables[1]=table;table=[]
    for rho in (0,30,40,80):
        for method in ('PCA-KM','MDSP','Oracle-FS'):
            r=lookup[f'pca_orientation_rho_{rho}',120,120,method]
            table.append(dict(rho=f'{rho/100:.1f}',Method=method,**recovery(r)))
    tables[2]=table;table=[]
    for n,t in dims:
        for method in ('PCA-KM','MDSP','Oracle-FS'):
            table.append(dict(N=n,T=t,Method=method,**recovery(lookup['partial',n,t,method])))
    tables[3]=table
    group={r['rule']:r for r in readcsv(a.group_counts)};table=[]
    for rule,name in [('fixed-(2, 2)','Fixed K=(2,2)'),('CV+parsimony-0','Minimum CV'),('CV+parsimony-0.01','CV+parsimony (1%)'),('fixed-(4, 4)','Fixed K=(4,4)')]:
        r=group[rule]
        table.append(dict(Rule=name,**{'K-correct':'—' if rule.startswith('fixed') else f'{float(r["requested_true"]):.3f}',
                         'Active centers':f'{float(r["active_total"]):.2f}','C-RE':cell(r,'common_re'),'Exact':f'{float(r["exact"]):.3f}'}))
    tables[4]=table
    parts=['# Simulation tables',
           'Parentheses are Monte Carlo standard errors. Exact is a replication-level recovery frequency. Inputs are the user-specified run outputs.']
    for number,table in tables.items():
        writecsv(out/f'table_{number}.csv',table)
        keys=list(table[0]);parts += [f'## Table {number}', '| '+' | '.join(keys)+' |','| '+' | '.join(['---']*len(keys))+' |']
        parts += ['| '+' | '.join(str(r[k]) for k in keys)+' |' for r in table]
    (out/'TABLES.md').write_text('\n\n'.join(parts)+'\n',encoding='utf-8')
    writecsv(out/'figure_2_data.csv',[r for r in rows if r['scenario'].startswith('pca_orientation_') and r['method'] in ('PCA-KM','MDSP')])
    print('Created Tables 1–4 and source data for Figure 2:',out)

if __name__=='__main__':main()
