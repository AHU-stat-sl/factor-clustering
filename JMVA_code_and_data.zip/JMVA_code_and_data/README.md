# 投稿代码与实证输入数据

本目录分为两个可以独立运行的部分，不附历史估计结果、参考结果、训练结果缓存或核验输出。

| 目录 | 内容 | 主要入口 |
| --- | --- | --- |
| `simulation/` | 正文模拟与组数选择诊断 | `run_simulations.py`、`run_group_counts.py` |
| `empirical/` | 四因子宏观实证分析及输入 Excel | `run_empirical.py` |

两边均有独立的 `README.md`、依赖清单、固定参数说明和算法代码副本，单独复制其中任一文件夹即可使用，不依赖另一个目录或原项目。

- `simulation/configs/core_tasks.csv` 是数据生成的随机种子清单，不是模拟结果。
- `empirical/data/transformed_data_final.xlsx` 是实证输入数据，予以保留。
- `smoke` 仅用于快速检查运行是否正常；正文结果需要使用 `full` 模式重新计算。
- 运行后才会在指定位置生成新结果。输出目录必须为空或尚不存在。
- 完整实证搜索保留 K=2,...,8、七个惩罚值、20→50 起点升级和排列合并规则，计算时间明显长于快速检查。

Python 3.12；NumPy、openpyxl 等具体版本见各目录的 `requirements.txt`。R 只用于绘图。
