"""Training-only multistart and permutation pooling; immutable staged checkpoints."""
import os
for key in ('OPENBLAS_NUM_THREADS','VECLIB_MAXIMUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ[key]='1'
from pathlib import Path
import sys,json,itertools,time,hashlib,csv,dataclasses
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np
import openpyxl
ROOT=Path(__file__).resolve().parent
import mdsp_core as s
R=4
OUT=Path(os.environ.get('JMVA_EMPIRICAL_OUTPUT',str(ROOT/'outputs/empirical')))
SOURCE=ROOT/'data/transformed_data_final.xlsx'
WORKERS=int(os.environ.get('JMVA_WORKERS','10'))
RATIOS=(.25,.5,1.,2.,4.,8.,16.)
SEED=20260919

def dump(p,q):
    tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(q,ensure_ascii=False,indent=2));tmp.replace(p)

def csvsave(name,rows):
    with (OUT/name).open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def perm(source,target):
    remaining=list(range(len(source)));indices=[]
    for v in target:
        j=next(j for j in remaining if source[j]==v);indices.append(j);remaining.remove(j)
    return indices

def reorder(result,indices):
    L,F,z,_,d=result;d=dict(d)
    d['active_group_counts']=','.join(d['active_group_counts'].split(',')[j] for j in indices)
    d['requested_group_counts']=','.join(d['requested_group_counts'].split(',')[j] for j in indices)
    d['final_centers']=json.dumps([json.loads(d['final_centers'])[j] for j in indices])
    return L[:,indices],F[:,indices],z[:,indices],float('nan'),d

def fit(x,k,ratio,kind,seed,warm=None):
    attempts=[]
    primary=4. if ratio>=8 else 2.
    secondary=2. if ratio>=8 else 4.
    for kap,outer in ((primary,480),(secondary,480),(primary,960),(secondary,960)):
        res=s.admm_estimator(x,k,ratio*np.sqrt(x.shape[1]),np.random.default_rng(seed),
            max_outer=outer,max_inner=18,initialization=kind,initial_solution=warm,
            perform_refit=False,return_diagnostics=True,kappa_over_t=kap)
        d=res[4];attempts.append({a:d[a] for a in ('converged','discovery_objective','scaled_primal','scaled_dual','relative_objective_change','iterations','kappa_over_t')})
        if d['converged']:break
    return res,dict(kind=kind,seed=seed,attempts=attempts)

def refit(x,result):
    d=result[4];rng=np.random.default_rng();rng.bit_generator.state=d['_refit_rng_state']
    return s.factor_specific_refit(x,result[2],tuple(map(int,d['active_group_counts'].split(','))),rng)

def savefit(p,result,L,F):
    np.savez_compressed(p,discovery_L=result[0],discovery_F=result[1],labels=result[2],loadings=L,factors=F)

def loadfit(p,d):
    with np.load(p) as a:return a['discovery_L'],a['discovery_F'],a['labels'],float('nan'),dict(d)

def historic(cvx):
    """Compute the fixed training warm-start recipe directly from the input data."""
    p=OUT/'historical_training.npz';jp=OUT/'historical_training.json'
    if jp.exists():return
    history=json.loads((ROOT/'configs/protocol.json').read_text())['historical_warm_start']
    ratio=history['ratio'];captured=[];original=s.mdsp_multistart
    def capture(*args,**kwargs):
        result=original(*args,**kwargs)
        if abs(args[2]/np.sqrt(288)-ratio)<1e-10 and result[4]['converged']:captured.append(result)
        return result
    s.mdsp_multistart=capture
    try:s.validation_alpha(cvx,tuple(history['K']),np.random.default_rng(SEED),return_diagnostics=True)
    finally:s.mdsp_multistart=original
    if not captured:raise RuntimeError('No converged candidate for the fixed training warm start.')
    L,F=captured[-1][:2];x=cvx[:,:288]
    score=s.validation_mse(L,cvx[:,288:])
    # Augment only with the leading TRAINING residual direction orthogonal to existing F.
    residual=x-(x@F/288)@F.T
    _,extra=s.pca_estimator(residual,1)
    extra-=F@(F.T@extra/288);extra*=np.sqrt(288)/np.linalg.norm(extra)
    L4=np.column_stack((L,x@extra/288));F4=np.column_stack((F,extra))
    assert np.max(abs(F4.T@F4/288-np.eye(R)))<1e-10
    np.savez_compressed(p,loadings=L,factors=F,augmented_loadings=L4,augmented_factors=F4)
    dump(jp,dict(K=history['K'],ratio=ratio,validation_mse=score))

def family(k,cvx,stage):
    x=cvx[:,:288];validation=cvx[:,288:];perms=sorted(set(itertools.permutations(k)))
    folder=OUT/f'stage{stage}';stem='_'.join(map(str,k));jp=folder/f'K_{stem}.json'
    if jp.exists():return json.loads(jp.read_text())
    records=[];previous=None
    old=None
    if stage==50:old=json.loads((OUT/'stage20'/f'K_{stem}.json').read_text())
    hist=json.loads((OUT/'historical_training.json').read_text())
    with np.load(OUT/'historical_training.npz') as h:history=(h['augmented_loadings'],h['augmented_factors'])
    for ai,ratio in enumerate(RATIOS):
        candidates=[];logs=[];independent=[]
        if old:
            candidates.append((loadfit(OUT/'stage20'/f'K_{stem}_a{ai}.npz',old['records'][ai]['diagnostics']),'stage20_incumbent'))
        for kk in perms:
            idx=perm(kk,k);local=[]
            ids=range(20) if stage==20 else range(20,50)
            for start in ids:
                kind='pca' if start==0 else ('random' if (15<=start<20 or start>=40) else 'rotated-pca')
                seed=int(np.random.SeedSequence([SEED,start]).generate_state(1)[0])
                res,log=fit(x,kk,ratio,kind,seed)
                logs.append(dict(K=kk,start=start,**log))
                if res[4]['converged']:local.append((reorder(res,idx),f'{kk}:{start}'))
            if previous is not None:
                pi=perm(k,kk);warm=(previous[0][:,pi],previous[1][:,pi])
                res,log=fit(x,kk,ratio,'warm',SEED+71,warm)
                logs.append(dict(K=kk,start='previous_alpha',**log))
                if res[4]['converged']:local.append((reorder(res,idx),f'{kk}:previous_alpha'))
            # Historical fit is training-only. Reoptimize at each alpha, not compare objectives across alpha.
            if True:
                hi=perm(k,kk)
                res,log=fit(x,kk,ratio,'warm',SEED+72,(history[0][:,hi],history[1][:,hi]))
                logs.append(dict(K=kk,start='historical_training',**log))
                if res[4]['converged']:local.append((reorder(res,idx),f'{kk}:history'))
            if local:
                chosen=min(local,key=lambda z:z[0][4]['discovery_objective']);candidates.extend(local)
                independent.append(dict(K=kk,objective=chosen[0][4]['discovery_objective']))
        if not candidates:raise RuntimeError(f'No converged candidate {k} {ratio}')
        shared=min(candidates,key=lambda z:z[0][4]['discovery_objective'])
        # Additional start in every equivalent ordering, followed by exact permutation pooling.
        for kk in perms:
            pi=perm(k,kk);res,log=fit(x,kk,ratio,'warm',SEED+73,(shared[0][0][:,pi],shared[0][1][:,pi]))
            logs.append(dict(K=kk,start='cross_permutation',**log))
            if res[4]['converged']:candidates.append((reorder(res,perm(kk,k)),f'{kk}:cross_permutation'))
        win,origin=min(candidates,key=lambda z:z[0][4]['discovery_objective'])
        L,F=refit(x,win);score=s.validation_mse(L,validation)
        assert np.max(abs(F.T@F/288-np.eye(R)))<1e-9
        savefit(folder/f'K_{stem}_a{ai}.npz',win,L,F)
        previous=(L,F)
        records.append(dict(alpha_ratio=ratio,validation_mse=score,diagnostics=win[4],origin=origin,
            independent_orderings=independent,starts=logs,base_starts_per_ordering=stage))
    result=dict(K=k,permutations=perms,records=records)
    dump(jp,result);return result

def pool_run(families,cvx,stage):
    (OUT/f'stage{stage}').mkdir(exist_ok=True);res=[]
    with ProcessPoolExecutor(max_workers=WORKERS) as pool:
        futures={pool.submit(family,k,cvx,stage):k for k in families}
        for f in as_completed(futures):
            q=f.result();res.append(q)
            print(f'stage{stage}: {len(res)}/{len(families)} families, K={q["K"]}',flush=True)
    return sorted(res,key=lambda q:q['K'])

def main():
    OUT.mkdir(parents=True,exist_ok=True);tic=time.time()
    wb=openpyxl.load_workbook(SOURCE,read_only=True,data_only=True);rows=list(wb.active.values);wb.close()
    names=list(rows[0][1:]);dates=[q[0].strftime('%Y-%m-%d') for q in rows[1:]]
    raw=np.array([q[1:] for q in rows[1:]],float).T
    assert raw.shape==(126,360) and np.isfinite(raw).all()
    cvx=(raw-raw[:,:288].mean(1,keepdims=True))/raw[:,:288].std(1,keepdims=True)
    x=(raw-raw.mean(1,keepdims=True))/raw.std(1,keepdims=True)
    manifest=dict(source_sha256=hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
        estimator_sha256=hashlib.sha256((ROOT/'mdsp_core.py').read_bytes()).hexdigest(),
        runner_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),seed=SEED,alpha_ratios=RATIOS,
        r=R,K_values=list(range(2,9)),workers=WORKERS,config=dataclasses.asdict(s.CONFIG),
        policy='20 nested base starts each ordered K, extra alpha/augmented_train_history/cross permutation warm; top10 unordered K all alphas increased to50; training objective pooling')
    manifest=json.loads(json.dumps(manifest));mp=OUT/'manifest.json'
    if mp.exists():assert json.loads(mp.read_text())==manifest
    else:dump(mp,manifest)
    historic(cvx)
    h=json.loads((OUT/'historical_training.json').read_text());a=np.load(OUT/'historical_training.npz')
    reproduced=s.validation_mse(a['loadings'],cvx[:,288:]);a.close()
    assert abs(reproduced-h['validation_mse'])<1e-8,(reproduced,h)
    families=list(itertools.combinations_with_replacement(range(2,9),R))
    first=pool_run(families,cvx,20)
    shortlist=sorted(set(tuple(q['K']) for q in sorted(first,key=lambda q:min(v['validation_mse'] for v in q['records']))[:10]))
    dump(OUT/'shortlist.json',shortlist)
    second=pool_run(shortlist,cvx,50)
    updated={tuple(q['K']):q for q in second};final=[updated.get(tuple(q['K']),q) for q in first]
    records=[]
    for q in final:
        for ai,v in enumerate(q['records']):
            before=next(a for a in first if tuple(a['K'])==tuple(q['K']))['records'][ai]
            assert v['diagnostics']['discovery_objective']<=before['diagnostics']['discovery_objective']+1e-8
            for kk in q['permutations']:
                records.append(dict(K=','.join(map(str,kk)),canonical_K=','.join(map(str,q['K'])),alpha_ratio=v['alpha_ratio'],
                    starts=v['base_starts_per_ordering'],validation_mse=v['validation_mse'],objective=v['diagnostics']['discovery_objective'],
                    objective20=before['diagnostics']['discovery_objective'],validation_mse20=before['validation_mse'],
                    converged=v['diagnostics']['converged']))
    csvsave('all_candidates.csv',records)
    winner=min(((q,v,i) for q in final for i,v in enumerate(q['records'])),key=lambda item:(item[1]['validation_mse'],tuple(item[0]['K']),item[1]['alpha_ratio']))
    q,v,ai=winner;k=tuple(q['K']);ratio=v['alpha_ratio']
    stage=v['base_starts_per_ordering'];stem='_'.join(map(str,k))
    train=np.load(OUT/f'stage{stage}'/f'K_{stem}_a{ai}.npz')
    np.savez_compressed(OUT/'selected_training.npz',**{key:train[key] for key in train.files});train.close()
    full_candidates=[];full_logs=[]
    for start in range(50):
        kind='pca' if start==0 else ('random' if (15<=start<20 or start>=40) else 'rotated-pca')
        seed=int(np.random.SeedSequence([SEED+100,start]).generate_state(1)[0])
        res,log=fit(x,k,ratio,kind,seed);full_logs.append(log)
        if res[4]['converged']:full_candidates.append(res)
    win=min(full_candidates,key=lambda z:z[4]['discovery_objective']);L,F=refit(x,win)
    z=win[2].copy()
    for j in range(R):
        if L[np.argmax(abs(L[:,j])),j]<0:L[:,j]*=-1;F[:,j]*=-1
        order=sorted(np.unique(z[:,j]),key=lambda g:L[z[:,j]==g,j].mean());mp={g:i+1 for i,g in enumerate(order)}
        z[:,j]=[mp[g] for g in z[:,j]]
    np.savez_compressed(OUT/'fit.npz',loadings=L,factors=F,labels=z,standardized_data=x)
    csvsave('variable_groups.csv',[dict(variable=name,**{f'group_{j+1}':int(z[i,j]) for j in range(R)},**{f'loading_{j+1}':float(L[i,j]) for j in range(R)}) for i,name in enumerate(names)])
    groups=[]
    for j in range(R):
        for g in np.unique(z[:,j]):
            ix=np.flatnonzero(z[:,j]==g);groups.append(dict(factor=j+1,group=int(g),center=float(L[ix,j].mean()),size=len(ix),variables=', '.join(names[i] for i in ix)))
    csvsave('group_centers.csv',groups)
    csvsave('factors.csv',[dict(date=date,**{f'factor_{j+1}':float(F[i,j]) for j in range(R)}) for i,date in enumerate(dates)])
    dump(OUT/'result.json',dict(selected_K=k,alpha_ratio=ratio,validation_mse=v['validation_mse'],full_mse=float(np.mean((x-L@F.T)**2)),
        diagnostics=win[4],full_start_logs=full_logs,total_candidates=len(records),converged_candidates=sum(r['converged'] for r in records),
        selected_stage=stage,elapsed_seconds=time.time()-tic,shortlist=shortlist,historical_reproduced_validation_mse=reproduced))
    print('DONE',k,ratio,v['validation_mse'],flush=True)

if __name__=='__main__':main()
