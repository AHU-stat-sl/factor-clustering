# Macroeconomic application

Self-contained four-factor analysis from `data/transformed_data_final.xlsx`.
The folder contains no previous estimates, selected training matrices,
reference tables or output caches. The Excel workbook is input data.

## Setup

Use Python 3.12 (tested with 3.12.14):

```sh
python3.12 -m venv .venv
source .venv/bin/activate
# Windows activation: .venv\Scripts\activate
python -m pip install -r requirements.txt
```

Run commands from this folder. BLAS threads are limited to one per worker.
Output directories must be new or empty.

## Quick execution check

```sh
python run_empirical.py --mode smoke --workers 2 --output outputs/smoke
```

This starts from the Excel file, reconstructs the fixed training warm start,
fits one demonstration K/alpha setting with a small start budget, and computes
PCA and matched-K PCA–KM comparators. It creates new training and full-sample
estimates. It does **not** search the full grid or produce manuscript estimates;
the mode is recorded in its output. The `--workers` option controls the full
parallel search; the small smoke calculation is sequential.

## Full manuscript analysis

```sh
python run_empirical.py --mode full --workers 10 --output outputs/full
python make_tables.py --input outputs/full --output outputs/tables
Rscript plot_figures.R outputs/tables outputs/figures
```

Full mode searches K in {2,...,8}^4 and seven alpha scales, pools equivalent
factor permutations, expands the top ten classes from 20 to 50 starts per
ordering, and applies minimum-MSE and 1% active-center selection. It independently
tunes PCA–KM and fits both selected MDSP models on the full sample. No published
selection or old training matrix is injected into this search. Complete runs
can take several hours; the highest penalty can be particularly slow.

Outputs include `method_comparison.csv`, the newly computed candidate search,
and `minimum_mse/` and `parsimony_1pct/` containing centers, memberships, factors
and fit diagnostics. Tables 5–6 and Figure 3 input are generated from these new
outputs. The figure reproduces profile counts, not the manuscript's exact
typesetting or representative-indicator annotations. Smoke outputs cannot be
used to generate the manuscript tables.

`mdsp_core.py` is a local copy of the same numerical engine used in the
simulations; no sibling-folder import is needed. `macro_multistart.py` contains
the staged search. `NUMERICAL_PROTOCOL.md` and `configs/protocol.json` define
settings. The three-factor K=(2,4,6), ratio=4 warm-start recipe is retained as an
initialization choice, but its matrices and validation score are recomputed
from the input data on every fresh run.

The sample has 126 indicators and 360 months. r=4 is prespecified; training
uses 288 months, validation 72. Validation measures contemporaneous reconstruction,
not forecasting. See `data/README.md` for standardization and upstream-data
provenance limits. Numerical convergence does not certify global optimality.
