"""Portable I/O and fixed-protocol checks (no estimation code)."""
import csv
import hashlib
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent
for name in ('OPENBLAS_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[name] = '1'

def readcsv(path):
    with Path(path).open(newline='', encoding='utf-8-sig') as f:
        return list(csv.DictReader(f))

def writecsv(path, rows):
    if not rows:
        raise ValueError('No rows to write')
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    keys = list(dict.fromkeys(k for row in rows for k in row))
    with path.open('w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=keys); w.writeheader(); w.writerows(rows)

def dump(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')

def protocol():
    return json.loads((ROOT / 'configs/protocol.json').read_text())

def check_core(study):
    actual = json.loads(json.dumps(study.asdict(study.CONFIG)))
    if actual != protocol()['numerical_settings']:
        raise RuntimeError('Estimator configuration differs from frozen protocol.')

def fresh_directory(path):
    path = Path(path).resolve()
    if path.exists() and any(path.iterdir()):
        raise FileExistsError(f'Output directory is not empty: {path}')
    path.mkdir(parents=True, exist_ok=True)
    return path

def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
