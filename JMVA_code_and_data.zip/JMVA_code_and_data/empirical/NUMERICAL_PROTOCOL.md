# Fixed empirical implementation

All calculations begin with the supplied processed Excel. Settings are frozen
in `configs/protocol.json`; there are no stored estimation results in this folder.
The numerical engine is `mdsp_core.py`, copied unchanged from the simulation
engine. The full search preserves its original discovery and refit functions.

## Data and validation

X is N by T, N=126, T=360, July 1995–June 2025. Fix r=4. The first 288 months
train the models; the last 72 validate them. Use each series' training mean and
SD (ddof=0) to standardize both blocks. Final fits instead use all 360 months'
mean and SD. Do not standardize the workbook beforehand.

For a refitted training loading matrix L, validation computes
mean((X_val - L A)^2), with A from `np.linalg.lstsq(L,X_val,rcond=None)`.
This is contemporaneous reconstruction. The validation period is used to tune
the model and is not an untouched forecast test set.

## Initialization and search

Search all 2,401 ordered K vectors in {2,...,8}^4 and penalty ratios
(0.25,0.5,1,2,4,8,16), with alpha=ratio*sqrt(sample length). Enumerate the 210
unordered classes and their distinct permutations in lexicographic order.
Pool converged fits after mapping columns to canonical sorted K; equal-count
columns use their first unused positions. Select the smallest **training
discovery objective**, RSS + alpha times nearest-center absolute deviations
of loadings, before hard refit and validation. First occurrence resolves exact
ties within the ordered start list.

Base seed j is the first generated state of SeedSequence([20260919,j]).
Stage 20: index 0 is PCA, 1..14 rotated PCA, 15..19 random. Stage 50 adds
20..39 rotated PCA and 40..49 random and retains the stage-20 incumbent.
This is the base budget **per distinct ordering**, with additional warm starts.

PCA uses the uncentered SVD X=UDV': L=U_r D_r/sqrt(T), F=sqrt(T)V_r.
Rotated PCA multiplies both by the QR factor of an r by r standard Gaussian
matrix. Random factors use QR of a T by r Gaussian matrix, F=sqrt(T)Q and
L=XF/T. Each discovery start sets Theta=L, dual=0 and initializes centers by
exact dynamic-programming one-dimensional k-medians. NumPy's SVD/QR signs are
not recanonicalized during fitting.

Additional warm starts are the previous alpha's refitted training solution
(seed 20260919+71), a fixed training-only initialization recipe (+72), and the
best pooled discovery fit reoptimized in every equivalent ordering (+73).
The fixed initialization recomputes a three-factor K=(2,4,6) training path
using the simulation alpha grid and seed 20260919, retaining its ratio-4 fit.
It augments that fit with the leading training-residual factor orthogonalized
against the existing factors. Its matrices and score are generated on the
current run; no external result file is read.

At stage 20, rank classes by best validation MSE, with lexicographic class order
resolving ties. Expand the best ten classes at every alpha to stage 50. Other
classes retain stage-20 estimates. Final selection uses the updated candidate
set, not the lowest validation score ever observed along the search.

Minimum-MSE selection minimizes (CV, canonical K, alpha ratio). The 1% rule
retains CV <=1.01*CV_min, then minimizes (training active-center count, CV,
requested-center count, canonical K, alpha ratio). Final fits use 50 starts
with SeedSequence([20261019,j]), the same start-type schedule, and the same
discovery ranking and refit rule.

## Convergence and refit

Primary kappa/T is 2 for ratio<8 and 4 otherwise. Each start tries
(primary,480), (other,480), (primary,960), (other,960), stopping at the first
convergence. Every attempt resets the same initialization seed. Smooth-block
cap is 18, center-update cap 12. Smooth updates stop when the sum of mean
squared changes in L and F is below 1e-9; center movement tolerance is 1e-9.
The center objective safeguard is 1e-12*max(1,current loss).

Discovery requires ||L-Theta||/sqrt(Nr)<2e-5,
||Theta-Theta_old||/sqrt(Nr)<2e-5, and relative original-objective change <1e-7.
Extract nearest-center labels from terminal Theta, remove inactive centers,
and merge each sorted active center c into the last retained center if their
distance is <=1e-8*max(1,abs(c)).

Fixed-membership least-squares refitting uses eight factor starts: PCA plus
seven Gaussian-QR starts. Alternate coordinate-center least squares and the
normalized orthogonal Procrustes factor update for at most 100 iterations,
stopping at relative RSS change <1e-10. Retain minimum RSS, resolving exact
ties by the first start. The chosen discovery start's saved RNG state supplies
its refit starts. Convergence does not certify global optimality.

For reporting, flip each loading/factor sign so its largest absolute loading
is positive, then relabel groups by ascending center order starting at 1.
The number of occupied crossed profiles is computed from the resulting labels.

## Comparators

PCA–KM independently searches all ordered K vectors on its fixed PCA axes.
Training RNG is 20260921; full-sample RNG is 20260923. Each coordinate uses
12 one-dimensional k-means starts: linear quantiles (g+0.5)/K and eleven samples
of K observation entries without replacement. Lloyd iterations have cap 80
and maximum-center-movement tolerance 1e-10. Empty groups are repaired from
the worst represented observation, with terminal repairs restricted to donor
groups of size >1. Choose minimum within-coordinate SSE and apply the same
eight-start grouped refit. Matched-K fits use the newly selected MDSP counts.

Explained fraction is 1 minus full-sample standardized reconstruction MSE.
Factors have F'F/T=I. Validation and full-sample fit use different scaling
moments, so their numerical error scales differ. The supplied smoke mode is
an execution check at one fixed K/alpha with a smaller budget; only full mode
performs the manuscript search.
