"""Estimate directly from the Excel input: full manuscript search or a small smoke run."""
import argparse
import itertools
import json
import math
import os
import platform
import sys
import time
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from common import ROOT, check_core, dump, fresh_directory, protocol, readcsv, sha256, writecsv
import macro_multistart as m
import numpy as np

def load_data():
    expected=protocol()['source_sha256']
    if sha256(m.SOURCE)!=expected:raise RuntimeError('Input workbook differs from the frozen manuscript dataset.')
    wb=m.openpyxl.load_workbook(m.SOURCE,read_only=True,data_only=True)
    rows=list(wb.active.values);wb.close()
    names=list(rows[0][1:]);dates=[r[0].strftime('%Y-%m-%d') for r in rows[1:]]
    raw=np.asarray([r[1:] for r in rows[1:]],float).T
    if raw.shape!=(126,360) or not np.isfinite(raw).all():raise ValueError('Expected a finite 126 by 360 panel.')
    if len(set(names))!=126 or len(set(dates))!=360 or dates!=sorted(dates):raise ValueError('Invalid names or dates.')
    sd=raw[:,:288].std(1,keepdims=True);fullsd=raw.std(1,keepdims=True)
    if np.any(sd<=0) or np.any(fullsd<=0):raise ValueError('Constant series found.')
    cvx=(raw-raw[:,:288].mean(1,keepdims=True))/sd
    x=(raw-raw.mean(1,keepdims=True))/fullsd
    return names,dates,cvx,x

def full_fit(x,k,ratio,out,names,dates,start_indices=range(50)):
    out.mkdir(parents=True,exist_ok=False)
    candidates=[];logs=[]
    for start in start_indices:
        kind='pca' if start==0 else ('random' if (15<=start<20 or start>=40) else 'rotated-pca')
        seed=int(np.random.SeedSequence([m.SEED+100,start]).generate_state(1)[0])
        res,log=m.fit(x,k,ratio,kind,seed);logs.append(log)
        if res[4]['converged']:candidates.append(res)
    if not candidates:raise RuntimeError(f'No converged full-sample start for {k}')
    win=min(candidates,key=lambda z:z[4]['discovery_objective'])
    L,F=m.refit(x,win);z=win[2].copy()
    if not np.isfinite(L).all() or not np.isfinite(F).all() or np.max(abs(F.T@F/x.shape[1]-np.eye(4)))>1e-8:
        raise RuntimeError('Invalid or unnormalized full-sample fit.')
    for j in range(4):
        if L[np.argmax(abs(L[:,j])),j]<0:L[:,j]*=-1;F[:,j]*=-1
        order=sorted(np.unique(z[:,j]),key=lambda g:L[z[:,j]==g,j].mean())
        mapping={g:i+1 for i,g in enumerate(order)};z[:,j]=[mapping[g] for g in z[:,j]]
    groups=[]
    for j in range(4):
        for g in np.unique(z[:,j]):
            ix=np.flatnonzero(z[:,j]==g)
            groups.append(dict(factor=j+1,group=int(g),center=float(L[ix,j].mean()),size=len(ix),variables=', '.join(names[i] for i in ix)))
    writecsv(out/'group_centers.csv',groups)
    writecsv(out/'variable_groups.csv',[dict(variable=name,**{f'group_{j+1}':int(z[i,j]) for j in range(4)},**{f'loading_{j+1}':float(L[i,j]) for j in range(4)}) for i,name in enumerate(names)])
    writecsv(out/'factors.csv',[dict(date=date,**{f'factor_{j+1}':float(F[i,j]) for j in range(4)}) for i,date in enumerate(dates)])
    np.savez_compressed(out/'fit.npz',loadings=L,factors=F,labels=z,discovery_L=win[0],discovery_F=win[1])
    result=dict(K=k,alpha_ratio=ratio,full_mse=float(np.mean((x-L@F.T)**2)),profiles=len(np.unique(z,axis=0)),
                valid_starts=len(candidates),diagnostics=win[4],full_start_logs=logs)
    dump(out/'result.json',result)
    return result

def km_candidate(job):
    k,train,validation=job
    L,_,_=m.s.pca_kmeans_estimator(train,k,np.random.default_rng(m.SEED+2))
    return dict(K=k,validation_mse=m.s.validation_mse(L,validation))

def selections_from_search(out):
    families={tuple(q['K']):q for p in sorted((out/'stage20').glob('K_*.json')) for q in [json.loads(p.read_text())]}
    families.update({tuple(q['K']):q for p in sorted((out/'stage50').glob('K_*.json')) for q in [json.loads(p.read_text())]})
    candidates=[(sum(map(int,v['diagnostics']['active_group_counts'].split(','))),v['validation_mse'],sum(k),k,v['alpha_ratio'],v)
                for k,q in families.items() for v in q['records']]
    cmin=min(q[1] for q in candidates)
    best=min(candidates,key=lambda q:(q[1],q[3],q[4]))
    compact=min((q for q in candidates if q[1]<=1.01*cmin),key=lambda q:q[:5])
    chosen={}
    for label,q in [('minimum_mse',best),('parsimony_1pct',compact)]:
        k,ratio,v=q[3:];ai=list(m.RATIOS).index(ratio)
        chosen[label]=dict(K=k,alpha_ratio=ratio,validation_mse=q[1],
            training_file=out/f'stage{v["base_starts_per_ordering"]}'/('K_'+'_'.join(map(str,k))+f'_a{ai}.npz'))
    return chosen

def smoke_run(out,names,dates,cvx,x):
    """Exercise fresh training, warm-start reconstruction, final fitting and comparators.

    Fixed K and alpha here are demonstration inputs, not a selection result.
    """
    k=(2,2,2,6);ratio=2.;train=cvx[:,:288];validation=cvx[:,288:]
    m.historic(cvx)
    candidates=[]
    for start,kind in [(0,'pca'),(1,'rotated-pca'),(15,'random')]:
        seed=int(np.random.SeedSequence([m.SEED,start]).generate_state(1)[0])
        result,_=m.fit(train,k,ratio,kind,seed)
        if result[4]['converged']:candidates.append(result)
    with np.load(out/'historical_training.npz') as h:
        warm=(h['augmented_loadings'],h['augmented_factors'])
    result,_=m.fit(train,k,ratio,'warm',m.SEED+72,warm)
    if result[4]['converged']:candidates.append(result)
    if not candidates:raise RuntimeError('No valid smoke training fit.')
    winner=min(candidates,key=lambda q:q[4]['discovery_objective']);L,F=m.refit(train,winner)
    result=full_fit(x,k,ratio,out/'smoke_model',names,dates,start_indices=(0,1,15))
    result['validation_mse']=m.s.validation_mse(L,validation)
    result['mode']='smoke';result['model_selection_performed']=False
    dump(out/'smoke_model/result.json',result)
    trainL,_=m.s.pca_estimator(train,4);fullL,fullF=m.s.pca_estimator(x,4)
    kmL,kmF,_=m.s.pca_kmeans_estimator(x,k,np.random.default_rng(m.SEED+4))
    rows=[dict(method='PCA',K='—',validation_mse=m.s.validation_mse(trainL,validation),explained=1-np.mean((x-fullL@fullF.T)**2),centers=504),
        dict(method='MDSP smoke only',K=str(k),validation_mse=result['validation_mse'],explained=1-result['full_mse'],centers=sum(map(int,result['diagnostics']['active_group_counts'].split(',')))),
        dict(method='PCA-KM smoke matched K',K=str(k),validation_mse=km_candidate((k,train,validation))['validation_mse'],explained=1-np.mean((x-kmL@kmF.T)**2),centers=sum(k))]
    writecsv(out/'method_comparison.csv',rows)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--mode',choices=['smoke','full'],default='smoke',help='smoke checks execution at fixed demonstration inputs; full performs manuscript K/alpha selection')
    p.add_argument('--workers',type=int,default=10)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args()
    if a.workers<1:p.error('workers must be positive')
    check_core(m.s);out=fresh_directory(a.output);tic=time.time()
    os.environ['JMVA_EMPIRICAL_OUTPUT']=str(out);os.environ['JMVA_WORKERS']=str(a.workers)
    m.OUT=out;m.WORKERS=a.workers
    names,dates,cvx,x=load_data();cfg=protocol()
    if m.R!=cfg['r'] or m.SEED!=cfg['seed'] or list(m.RATIOS)!=cfg['alpha_ratios'] or cfg['K_values']!=list(range(2,9)):
        raise RuntimeError('Empirical configuration differs from the fixed protocol.')
    if a.mode=='smoke':
        smoke_run(out,names,dates,cvx,x)
        dump(out/'run_info.json',dict(mode='smoke',model_selection_performed=False,
            note='Execution check only: fixed K/alpha and reduced start budget; not manuscript results.',
            elapsed_seconds=time.time()-tic,python=platform.python_version(),numpy=np.__version__,source_sha256=sha256(m.SOURCE)))
        print('Smoke run finished; no full model selection performed. Outputs:',out)
        return
    m.main()
    chosen=selections_from_search(out)
    with ProcessPoolExecutor(max_workers=a.workers) as pool:
        km=list(pool.map(km_candidate,((k,cvx[:,:288],cvx[:,288:]) for k in itertools.product(range(2,9),repeat=4))))
    km.sort(key=lambda q:q['K']);dump(out/'pca_km_grid.json',km)
    bestkm=tuple(min(km,key=lambda q:q['validation_mse'])['K'])
    results={}
    for label,q in chosen.items():
        with np.load(q['training_file']) as fit:score=m.s.validation_mse(fit['loadings'],cvx[:,288:])
        if abs(score-q['validation_mse'])>1e-8:raise RuntimeError('Training projection differs from stored score.')
        results[label]=full_fit(x,tuple(q['K']),q['alpha_ratio'],out/label,names,dates)
        results[label]['validation_mse']=score
        dump(out/label/'result.json',results[label])
        print(label,results[label]['K'],score,results[label]['full_mse'],flush=True)
    trainL,_=m.s.pca_estimator(cvx[:,:288],4);L,F=m.s.pca_estimator(x,4)
    methods=[dict(method='PCA (r=4)',K='—',validation_mse=m.s.validation_mse(trainL,cvx[:,288:]),explained=1-np.mean((x-L@F.T)**2),centers=504)]
    for label,name in [('parsimony_1pct','MDSP: 1% parsimony'),('minimum_mse','MDSP (r=4)')]:
        q=results[label]
        methods.append(dict(method=name,K=str(tuple(q['K'])),validation_mse=q['validation_mse'],explained=1-q['full_mse'],centers=sum(map(int,q['diagnostics']['active_group_counts'].split(',')))))
    for name,k in [('PCA–KM tuned K',bestkm),('PCA–KM matched to 12-center K',tuple(chosen['parsimony_1pct']['K'])),('PCA–KM matched K',tuple(chosen['minimum_mse']['K']))]:
        score=km_candidate((k,cvx[:,:288],cvx[:,288:]))['validation_mse']
        L,F,_=m.s.pca_kmeans_estimator(x,k,np.random.default_rng(m.SEED+4))
        methods.append(dict(method=name,K=str(k),validation_mse=score,explained=1-np.mean((x-L@F.T)**2),centers=sum(k)))
    writecsv(out/'method_comparison.csv',methods)
    dump(out/'run_info.json',dict(mode='full',model_selection_performed=True,
        selected_specifications={k:dict(K=v['K'],alpha_ratio=v['alpha_ratio'],validation_mse=v['validation_mse']) for k,v in chosen.items()},
        elapsed_seconds=time.time()-tic,python=platform.python_version(),numpy=np.__version__,
        source_sha256=sha256(m.SOURCE)))
    print('Full empirical analysis finished. Outputs:',out,flush=True)

if __name__=='__main__':main()
