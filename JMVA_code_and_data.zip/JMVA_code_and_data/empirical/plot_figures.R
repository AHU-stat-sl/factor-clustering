# Portable base-R rendering. First run make_tables.py.
args <- commandArgs(trailingOnly=TRUE)
if (length(args) != 2) stop('Usage: Rscript plot_figures.R TABLE_DIRECTORY OUTPUT_DIRECTORY')
if (dir.exists(args[2]) && length(list.files(args[2],all.files=TRUE,no..=TRUE))) stop('Output directory must be new or empty')
dir.create(args[2], recursive=TRUE, showWarnings=FALSE)
# Native R devices only. PDF text remains editable; PNG is a convenience export.
open_figure <- function(name, width, height) {
  prefix <<- file.path(args[2], name); figure_width <<- width; figure_height <<- height
  measured_panels <<- character()
  if (identical(Sys.getenv('JMVA_CAIRO'),'1')) {
    cairo_pdf(paste0(prefix,'.pdf'),width=width,height=height,family='Helvetica',pointsize=12,bg='white')
  } else {
    pdf(paste0(prefix,'.pdf'),width=width,height=height,family='Helvetica',pointsize=12,useDingbats=FALSE,bg='white')
  }
  dev.control(displaylist='enable')
}
measure_panel <- function(id, row, col) {
  u <- par('usr'); xx <- sort(grconvertX(u[1:2], 'user', 'ndc'))*figure_width*72
  yy <- sort(grconvertY(u[3:4], 'user', 'ndc'))*figure_height*72
  measured_panels <<- c(measured_panels, sprintf('{"id":"%s","bbox_pt":[%.8f,%.8f,%.8f,%.8f],"grid_id":"main","row_start":%d,"row_stop":%d,"col_start":%d,"col_stop":%d}',id,xx[1],yy[1],xx[2],yy[2],row,row+1,col,col+1))
}
close_figure <- function() {
  snapshot <- recordPlot()
  manifest <- sprintf('{"schema_version":1,"backend":"base-R","figure":{"width_pt":%.8f,"height_pt":%.8f},"panels":[%s]}',figure_width*72,figure_height*72,paste(measured_panels,collapse=','))
  writeLines(manifest,paste0(prefix,'.alignment-layout.json'))
  dev.off()
  # Optional SVG needs a working Cairo library; it is not required for PDF replication.
  if (identical(Sys.getenv('JMVA_EXPORT_SVG'),'1')) {
    svg(paste0(prefix,'.svg'),width=figure_width,height=figure_height,family='Helvetica');replayPlot(snapshot);dev.off()
  }
  bitmap_type <- if(Sys.info()[['sysname']]=='Darwin') 'quartz' else 'cairo'
  png(paste0(prefix,'.png'),width=figure_width,height=figure_height,units='in',res=300,type=bitmap_type,bg='white');replayPlot(snapshot);dev.off()
}
# Data-equivalent crossed-profile display; manuscript typography may differ.
g <- read.csv(file.path(args[1], 'figure_3_data.csv'))
stopifnot(nrow(g)>0, sum(g$count)==126, all(g$count>0), all(as.matrix(g[,1:4])>=1))
open_figure('figure_3_macro_profiles',7.2,5.4)
layout(matrix(c(1,2), nrow=1), widths=c(1.15,1))
par(mar=c(4.2,1,2,1))
plot(NA, xlim=c(.5,4.5), ylim=c(nrow(g)+.5,.5), xlab='', ylab='', axes=FALSE)
for (i in seq_len(nrow(g))) for (j in 1:4) {
  shade <- grDevices::colorRampPalette(c('#F3F6FA','#9DC3E6'))(max(as.matrix(g[,1:4])))[g[i,j]]
  rect(j-.48,i-.46,j+.48,i+.46,col=shade,border='white')
  text(j,i,g[i,j],cex=.85)
}
axis(3,at=1:4,labels=paste0('F',1:4),tick=FALSE)
measure_panel('profiles',0,0)
par(mar=c(4.2,0,2,2))
plot(NA,xlim=c(0,max(g$count)*1.18),ylim=c(nrow(g)+.5,.5),xlab='Number of indicators',ylab='',axes=FALSE)
for(i in seq_len(nrow(g))) {
  rect(0,i-.35,g$count[i],i+.35,col='#0072B2',border=NA)
  text(g$count[i]+.6,i,g$count[i],adj=0,cex=.8)
}
axis(1);box(bty='l');measure_panel('counts',0,1);close_figure()
