"""Format Tables 5-6 and Figure 3 input from a freshly completed full empirical run."""
import argparse
import json
from collections import Counter
from pathlib import Path
from common import readcsv, writecsv, fresh_directory

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,required=True,help='Output directory from run_empirical.py --mode full')
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args()
    info=a.input/'run_info.json'
    if info.exists() and json.loads(info.read_text()).get('mode')!='full':
        p.error('Manuscript tables require a full run; smoke outputs are execution checks only.')
    methods=readcsv(a.input/'method_comparison.csv')
    groups=readcsv(a.input/'parsimony_1pct/group_centers.csv')
    members=readcsv(a.input/'parsimony_1pct/variable_groups.csv')
    out=fresh_directory(a.output)
    tables={5:[dict(Method=r['method'],K=r['K'],**{'Validation MSE':f'{float(r["validation_mse"]):.4f}',
        'Full-sample explained (%)':f'{100*float(r["explained"]):.2f}',
        'Loading coefficients/centers':r['centers']}) for r in methods]}
    max_group=max(int(r['group']) for r in groups)
    tables[6]=[dict(Factor=j,**{f'Group {g}':next((f'{float(r["center"]):.4f} ({r["size"]})'
        for r in groups if int(r['factor'])==j and int(r['group'])==g),'—')
        for g in range(1,max_group+1)}) for j in range(1,5)]
    parts=['# Empirical tables','Inputs are the specified completed analysis. Table 6 parentheses are group sizes.']
    for number,table in tables.items():
        writecsv(out/f'table_{number}.csv',table)
        keys=list(table[0]);parts += [f'## Table {number}','| '+' | '.join(keys)+' |','| '+' | '.join(['---']*len(keys))+' |']
        parts += ['| '+' | '.join(str(row[k]) for k in keys)+' |' for row in table]
    (out/'TABLES.md').write_text('\n\n'.join(parts)+'\n',encoding='utf-8')
    counts=Counter(tuple(int(r[f'group_{j}']) for j in range(1,5)) for r in members)
    writecsv(out/'figure_3_data.csv',[dict(**{f'F{j+1}':v for j,v in enumerate(k)},count=n) for k,n in sorted(counts.items())])
    print('Created Tables 5–6 and source data for Figure 3:',out)

if __name__=='__main__':main()
