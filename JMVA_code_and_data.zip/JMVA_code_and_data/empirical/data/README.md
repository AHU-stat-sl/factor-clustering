# Processed empirical input

`transformed_data_final.xlsx` is copied without numerical or metadata changes
from the actual analysis input. Its SHA-256 is recorded in
`configs/protocol.json` and is checked before fitting.

The first worksheet has a header row, a date column, and 126 indicator columns.
There are 360 monthly observations, July 1995 through June 2025. No missing
values are expected. Column and date order must remain unchanged.

Training uses the first 288 months (through June 2019); validation uses the last
72. Each series is centered/scaled using its training mean and population
standard deviation (ddof=0) for both blocks. Full-sample refits instead use
full-sample moments. These standardizations are performed by the code; do not
apply them to the workbook in advance.

The input is already transformed. This package does not reconstruct its raw
download, data-vintage selection, TCODE transformations, or earlier missing-value
processing. Those upstream records were not present with the supplied workbook.
The authors should provide any required provenance and redistribution terms
separately; replacing this file with the latest online data is not an exact
replication of the reported sample.
