#!/usr/bin/env python3
"""Monte Carlo experiments reported in the V2 simulation study.

The implementation follows the normalized least-squares ADMM estimator and
uses only NumPy plus the Python standard library.
"""

from __future__ import annotations

import argparse
import copy
import csv
import itertools
import json
import math
import multiprocessing as mp
import platform
import sys
import time
from collections import defaultdict
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import numpy as np


SCRIPT_DIR = Path(__file__).resolve().parent


@dataclass(frozen=True)
class DesignSpec:
    """A named Monte Carlo perturbation.

    Keeping the perturbations explicit prevents a design such as ``weak`` from
    being misread as a pure center-separation experiment when it also changes
    factor strength.
    """

    name: str
    structure: str = "crossed"
    loading_scale: float = 1.0
    matched_separation: bool = False
    loading_jitter: float = 0.0
    error_distribution: str = "gaussian"
    cross_rho: float = 0.30
    serial_rho: float = 0.0
    heteroskedastic: bool = False
    pca_orientation_rho: float | None = None


@dataclass
class GeneratedPanel:
    x: np.ndarray
    loadings: np.ndarray
    factors: np.ndarray
    errors: np.ndarray
    labels: np.ndarray
    profiles: np.ndarray
    group_counts: tuple[int, ...]
    orientation_identified: bool
    diagnostics: dict[str, float | int | str]


@dataclass(frozen=True)
class SimulationConfig:
    """Numerical settings that determine the reported Monte Carlo results."""

    alpha_ratios: tuple[float, ...] = (0.25, 0.50, 1.00, 2.00, 4.00)
    validation_fraction: float = 0.80
    cv_starts: int = 3
    cv_retry_starts: int = 6
    final_starts: int = 8
    final_retry_starts: int = 12
    max_outer: int = 120
    final_retry_max_outer: int = 240
    cv_max_outer: int = 120
    cv_retry_max_outer: int = 240
    cv_emergency_max_outer: int = 480
    max_inner: int = 25
    cv_max_inner: int = 18
    center_max_iter: int = 12
    residual_tolerance: float = 2e-5
    objective_tolerance: float = 1e-7
    center_tolerance: float = 1e-9
    center_merge_tolerance: float = 1e-8
    center_objective_tolerance: float = 1e-12
    smooth_change_tolerance: float = 1e-9
    pca_kmeans_starts: int = 12
    vector_kmeans_starts: int = 16
    factor_refit_starts: int = 8
    common_vector_refit_starts: int = 8
    kappa_over_t: float = 1.0
    kappa_retry_ratios: tuple[float, ...] = (2.0, 4.0)


CONFIG = SimulationConfig()

METHOD_SEED_NAMESPACE = 20260909
METHOD_STREAM_NAMES = (
    "pca_kmeans",
    "tuning",
    "mdsp",
    "oracle_fs",
    "cv_budget",
    "cv_profile",
    "oracle_cv",
)
CHECKPOINT_EVERY = 20


def start_allocation(starts: int, has_warm: bool = False) -> dict[str, int]:
    """Return the fixed-budget start allocation used by fitting and metadata."""
    if starts < 1:
        raise ValueError("starts must be positive")
    if has_warm and starts < 2:
        raise ValueError("at least two starts are required when using a warm start")
    random_starts = 0 if starts == 1 else max(1, starts // 4)
    if has_warm:
        random_starts = min(random_starts, starts - 2)
    allocation = {
        "warm": int(has_warm),
        "pca": 1,
        "rotated_pca": starts - 1 - random_starts - int(has_warm),
        "random": random_starts,
    }
    return allocation


def base_initializations(starts: int, has_warm: bool = False) -> list[str]:
    """Expand a base-start count into the corresponding initialization names."""
    allocation = start_allocation(starts, has_warm=has_warm)
    return (
        ["pca"] * allocation["pca"]
        + ["rotated-pca"] * allocation["rotated_pca"]
        + ["random"] * allocation["random"]
    )


def replication_rngs(
    seed: int,
) -> tuple[np.random.Generator, dict[str, np.random.Generator]]:
    """Create a historical DGP stream and independent method-level streams."""
    dgp_rng = np.random.default_rng(seed)
    child_seeds = np.random.SeedSequence([seed, METHOD_SEED_NAMESPACE]).spawn(
        len(METHOD_STREAM_NAMES)
    )
    return dgp_rng, {
        name: np.random.default_rng(child)
        for name, child in zip(METHOD_STREAM_NAMES, child_seeds)
    }


DESIGNS: dict[str, DesignSpec] = {
    # The first four entries reproduce the original manuscript designs.
    "baseline": DesignSpec("baseline"),
    "weak": DesignSpec("weak", loading_scale=0.55),
    "heavy": DesignSpec("heavy", error_distribution="t5"),
    "dependence": DesignSpec("dependence", cross_rho=0.65),
    # Innovation-targeted and assumption-stress designs.
    "partial": DesignSpec("partial", structure="partial"),
    "unbalanced": DesignSpec("unbalanced", structure="unbalanced"),
    "aligned_boundary": DesignSpec("aligned_boundary", structure="aligned"),
    "separation_matched": DesignSpec(
        "separation_matched", matched_separation=True
    ),
    "approximate": DesignSpec("approximate", loading_jitter=0.12),
    "serial": DesignSpec("serial", serial_rho=0.50),
    "heteroskedastic": DesignSpec("heteroskedastic", heteroskedastic=True),
    "t3": DesignSpec("t3", error_distribution="t3"),
    "contamination": DesignSpec("contamination", error_distribution="contamination"),
    # Controlled PCA-orientation stress path.  Marginal group balance, loading
    # strengths, center gaps, and the error process are fixed; only the
    # correlation between the first two structural label coordinates changes.
    "pca_orientation_rho_0": DesignSpec(
        "pca_orientation_rho_0", structure="pca_orientation", pca_orientation_rho=0.0
    ),
    "pca_orientation_rho_10": DesignSpec(
        "pca_orientation_rho_10", structure="pca_orientation", pca_orientation_rho=0.1
    ),
    "pca_orientation_rho_20": DesignSpec(
        "pca_orientation_rho_20", structure="pca_orientation", pca_orientation_rho=0.2
    ),
    "pca_orientation_rho_30": DesignSpec(
        "pca_orientation_rho_30", structure="pca_orientation", pca_orientation_rho=0.3
    ),
    "pca_orientation_rho_40": DesignSpec(
        "pca_orientation_rho_40", structure="pca_orientation", pca_orientation_rho=0.4
    ),
    "pca_orientation_rho_50": DesignSpec(
        "pca_orientation_rho_50", structure="pca_orientation", pca_orientation_rho=0.5
    ),
    "pca_orientation_rho_60": DesignSpec(
        "pca_orientation_rho_60", structure="pca_orientation", pca_orientation_rho=0.6
    ),
    "pca_orientation_rho_70": DesignSpec(
        "pca_orientation_rho_70", structure="pca_orientation", pca_orientation_rho=0.7
    ),
    "pca_orientation_rho_80": DesignSpec(
        "pca_orientation_rho_80", structure="pca_orientation", pca_orientation_rho=0.8
    ),
}


def normalize_fitted(common: np.ndarray, r: int) -> tuple[np.ndarray, np.ndarray]:
    """Return (loadings, factors) with F'F/T=I and decreasing loading norms."""
    n, t = common.shape
    u, s, vt = np.linalg.svd(common, full_matrices=False)
    loadings = u[:, :r] * (s[:r] / math.sqrt(t))
    factors = math.sqrt(t) * vt[:r, :].T
    return loadings, factors


def pca_estimator(x: np.ndarray, r: int) -> tuple[np.ndarray, np.ndarray]:
    return normalize_fitted(x, r)


def procrustes_factor(x: np.ndarray, loadings: np.ndarray) -> np.ndarray:
    """Exact factor update under F'F/T=I for fixed loadings."""
    _, t = x.shape
    u, _, vt = np.linalg.svd(x.T @ loadings, full_matrices=False)
    return math.sqrt(t) * (u @ vt)


def kmeans_1d(
    x: np.ndarray,
    k: int,
    rng: np.random.Generator,
    n_init: int = 8,
    max_iter: int = 80,
) -> tuple[np.ndarray, np.ndarray, float]:
    """Small, deterministic-plus-random one-dimensional K-means."""
    x = np.asarray(x, dtype=float).reshape(-1)
    if k == 1:
        c = np.array([x.mean()])
        return c, np.zeros(x.size, dtype=int), float(np.sum((x - c[0]) ** 2))

    quantiles = np.quantile(x, (np.arange(k) + 0.5) / k)
    starts = [quantiles]
    for _ in range(max(0, n_init - 1)):
        starts.append(rng.choice(x, size=k, replace=False))

    best = None
    for start in starts:
        centers = np.sort(np.asarray(start, dtype=float))
        labels = np.zeros(x.size, dtype=int)
        for _ in range(max_iter):
            new_labels = np.argmin((x[:, None] - centers[None, :]) ** 2, axis=1)
            new_centers = centers.copy()
            for group in range(k):
                members = x[new_labels == group]
                if members.size:
                    new_centers[group] = members.mean()
                else:
                    loss = (x - centers[new_labels]) ** 2
                    new_centers[group] = x[int(np.argmax(loss))]
            order = np.argsort(new_centers)
            inverse = np.empty(k, dtype=int)
            inverse[order] = np.arange(k)
            new_centers = new_centers[order]
            new_labels = inverse[new_labels]
            if np.max(np.abs(new_centers - centers)) < 1e-10:
                centers, labels = new_centers, new_labels
                break
            centers, labels = new_centers, new_labels
        for group in range(k):
            if np.any(labels == group):
                continue
            counts = np.bincount(labels, minlength=k)
            eligible = counts[labels] > 1
            losses = (x - centers[labels]) ** 2
            losses[~eligible] = -math.inf
            labels[int(np.argmax(losses))] = group
        centers = np.array([x[labels == group].mean() for group in range(k)])
        order = np.argsort(centers)
        inverse = np.empty(k, dtype=int)
        inverse[order] = np.arange(k)
        centers, labels = centers[order], inverse[labels]
        loss = float(np.sum((x - centers[labels]) ** 2))
        if best is None or loss < best[2]:
            best = (centers.copy(), labels.copy(), loss)
    assert best is not None
    return best


def exact_kmedians_1d(x: np.ndarray, k: int) -> tuple[np.ndarray, np.ndarray, float]:
    """Globally solve one-dimensional K-medians by dynamic programming."""
    values = np.asarray(x, dtype=float).reshape(-1)
    n = values.size
    if not 1 <= k <= n:
        raise ValueError("the number of median groups must lie between 1 and N")

    order = np.argsort(values, kind="stable")
    sorted_values = values[order]
    prefix = np.concatenate(([0.0], np.cumsum(sorted_values)))
    starts = np.arange(n)[:, None]
    ends = np.arange(n)[None, :]
    medians = (starts + ends) // 2
    median_values = sorted_values[medians]
    left_cost = median_values * (medians - starts) - (
        prefix[medians] - prefix[starts]
    )
    right_cost = (
        prefix[ends + 1] - prefix[medians + 1]
        - median_values * (ends - medians)
    )
    segment_cost = np.where(starts <= ends, left_cost + right_cost, math.inf)

    dp = np.full((k + 1, n + 1), math.inf)
    previous = np.full((k + 1, n + 1), -1, dtype=int)
    dp[0, 0] = 0.0
    for groups in range(1, k + 1):
        # Evaluate every endpoint for this DP layer at once.  This is exactly
        # the same recurrence as the former endpoint loop,
        #
        #   dp[g, e] = min_m dp[g - 1, m] + cost(m, e - 1),
        #
        # but it avoids millions of tiny arange/argmin allocations across a
        # simulation run.  Invalid splits remain +inf through the preceding
        # DP layer and the upper triangle of segment_cost.  np.argmin keeps
        # the former smallest-split tie rule because rows are in ascending
        # split order.
        candidates = dp[groups - 1, :n, None] + segment_cost
        best_splits = np.argmin(candidates, axis=0)
        endpoints = np.arange(groups - 1, n)
        selected_splits = best_splits[endpoints]
        previous[groups, endpoints + 1] = selected_splits
        dp[groups, endpoints + 1] = candidates[selected_splits, endpoints]

    sorted_labels = np.empty(n, dtype=int)
    centers = np.empty(k, dtype=float)
    end = n
    for groups in range(k, 0, -1):
        start = previous[groups, end]
        sorted_labels[start:end] = groups - 1
        centers[groups - 1] = sorted_values[(start + end - 1) // 2]
        end = start
    labels = np.empty(n, dtype=int)
    labels[order] = sorted_labels
    return centers, labels, float(dp[k, n])


def collapse_active_centers(
    theta: np.ndarray,
    centers: np.ndarray,
    tolerance: float,
) -> tuple[np.ndarray, np.ndarray]:
    """Drop inactive centers, merge coincident centers, and relabel densely."""
    centers = np.asarray(centers, dtype=float).reshape(-1)
    labels = np.argmin(np.abs(theta[:, None] - centers[None, :]), axis=1)
    active = np.unique(labels)
    active_centers = centers[active]
    active_order = np.argsort(active_centers)
    active = active[active_order]
    active_centers = active_centers[active_order]

    merged_centers: list[float] = []
    old_to_new: dict[int, int] = {}
    for old_label, center in zip(active, active_centers):
        scale = max(1.0, abs(float(center)))
        if merged_centers and abs(float(center) - merged_centers[-1]) <= tolerance * scale:
            old_to_new[int(old_label)] = len(merged_centers) - 1
        else:
            merged_centers.append(float(center))
            old_to_new[int(old_label)] = len(merged_centers) - 1
    collapsed_labels = np.array([old_to_new[int(label)] for label in labels], dtype=int)
    return np.asarray(merged_centers), collapsed_labels


def kmeans_nd(
    x: np.ndarray,
    k: int,
    rng: np.random.Generator,
    n_init: int = 12,
    max_iter: int = 100,
) -> tuple[np.ndarray, np.ndarray, float]:
    """Multivariate K-means used by common-vector-partition benchmarks."""
    x = np.asarray(x, dtype=float)
    if x.ndim != 2:
        raise ValueError("kmeans_nd expects an N by r matrix")
    n = x.shape[0]
    if not 1 <= k <= n:
        raise ValueError("the number of vector clusters must lie between 1 and N")
    if k == 1:
        center = x.mean(axis=0, keepdims=True)
        labels = np.zeros(n, dtype=int)
        return center, labels, float(np.sum((x - center) ** 2))

    best = None
    deterministic = np.linspace(0, n - 1, k, dtype=int)
    starts = [x[np.argsort(x[:, 0])[deterministic]]]
    for _ in range(max(0, n_init - 1)):
        # K-means++ seeding makes the high-K profile comparison much more
        # stable than choosing all initial centers uniformly at random.
        chosen = [int(rng.integers(n))]
        while len(chosen) < k:
            distance = np.min(
                np.sum((x[:, None, :] - x[np.array(chosen)][None, :, :]) ** 2, axis=2),
                axis=1,
            )
            total = float(distance.sum())
            if total <= 1e-14:
                remaining = np.setdiff1d(np.arange(n), np.array(chosen))
                chosen.append(int(rng.choice(remaining)))
            else:
                chosen.append(int(rng.choice(n, p=distance / total)))
        starts.append(x[np.array(chosen)])

    for start in starts:
        centers = np.asarray(start, dtype=float).copy()
        labels = np.zeros(n, dtype=int)
        for _ in range(max_iter):
            distance = np.sum((x[:, None, :] - centers[None, :, :]) ** 2, axis=2)
            new_labels = np.argmin(distance, axis=1)
            new_centers = centers.copy()
            for group in range(k):
                members = x[new_labels == group]
                if members.size:
                    new_centers[group] = members.mean(axis=0)
                else:
                    largest = int(np.argmax(np.min(distance, axis=1)))
                    new_centers[group] = x[largest]
            if np.max(np.abs(new_centers - centers)) < 1e-10:
                centers, labels = new_centers, new_labels
                break
            centers, labels = new_centers, new_labels
        for group in range(k):
            if np.any(labels == group):
                continue
            counts = np.bincount(labels, minlength=k)
            eligible = counts[labels] > 1
            losses = np.sum((x - centers[labels]) ** 2, axis=1)
            losses[~eligible] = -math.inf
            labels[int(np.argmax(losses))] = group
        centers = np.vstack([x[labels == group].mean(axis=0) for group in range(k)])
        loss = float(np.sum((x - centers[labels]) ** 2))
        if best is None or loss < best[2]:
            best = (centers.copy(), labels.copy(), loss)
    assert best is not None
    return best


def factor_specific_refit(
    x: np.ndarray,
    labels: np.ndarray,
    group_counts: tuple[int, ...],
    rng: np.random.Generator,
    n_init: int = CONFIG.factor_refit_starts,
    max_iter: int = 100,
) -> tuple[np.ndarray, np.ndarray]:
    """Least-squares refit with one known membership matrix per factor."""
    n, t = x.shape
    r = len(group_counts)
    _, pca_factors = pca_estimator(x, r)
    starts = [pca_factors]
    for _ in range(max(0, n_init - 1)):
        q, _ = np.linalg.qr(rng.standard_normal((t, r)))
        starts.append(math.sqrt(t) * q[:, :r])

    best = None
    for start in starts:
        factors = start.copy()
        loadings = np.zeros((n, r))
        previous = math.inf
        for _ in range(max_iter):
            for j, count in enumerate(group_counts):
                h = np.column_stack(
                    [(labels[:, j] == group).astype(float) for group in range(count)]
                )
                counts = h.T @ h
                if np.min(np.diag(counts)) <= 0:
                    raise ValueError("factor-specific refit received an empty group")
                centers = np.linalg.solve(counts, h.T @ x @ factors[:, j] / t)
                loadings[:, j] = h @ centers
            factors = procrustes_factor(x, loadings)
            objective = float(np.sum((x - loadings @ factors.T) ** 2))
            if abs(previous - objective) / max(1.0, abs(objective)) < 1e-10:
                break
            previous = objective
        if best is None or objective < best[0]:
            best = (objective, loadings.copy(), factors.copy())
    assert best is not None
    return best[1], best[2]


def common_vector_refit(
    x: np.ndarray,
    labels: np.ndarray,
    r: int,
    rng: np.random.Generator,
    n_init: int = CONFIG.factor_refit_starts,
    max_iter: int = 100,
) -> tuple[np.ndarray, np.ndarray]:
    """Least-squares refit under one common partition of loading vectors."""
    n, t = x.shape
    labels = np.asarray(labels, dtype=int).reshape(-1)
    if labels.size != n:
        raise ValueError("common-vector labels must have length N")
    unique, labels = np.unique(labels, return_inverse=True)
    k = len(unique)
    membership = np.column_stack([(labels == group).astype(float) for group in range(k)])
    counts = membership.T @ membership
    if np.min(np.diag(counts)) <= 0:
        raise ValueError("common-vector refit received an empty group")

    _, pca_factors = pca_estimator(x, r)
    starts = [pca_factors]
    for _ in range(max(0, n_init - 1)):
        q, _ = np.linalg.qr(rng.standard_normal((t, r)))
        starts.append(math.sqrt(t) * q[:, :r])

    best = None
    for start in starts:
        factors = start.copy()
        previous = math.inf
        for _ in range(max_iter):
            centers = np.linalg.solve(counts, membership.T @ x @ factors / t)
            loadings = membership @ centers
            factors = procrustes_factor(x, loadings)
            objective = float(np.sum((x - loadings @ factors.T) ** 2))
            if abs(previous - objective) / max(1.0, abs(objective)) < 1e-10:
                break
            previous = objective
        if best is None or objective < best[0]:
            best = (objective, loadings.copy(), factors.copy())
    assert best is not None
    return best[1], best[2]


def factor_labels(
    n: int,
    rng: np.random.Generator,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Balanced Cartesian-product memberships for K=(2,3,2)."""
    combinations = np.array(list(itertools.product(range(2), range(3), range(2))))
    repeated = np.vstack([combinations for _ in range(math.ceil(n / len(combinations)))])[:n]
    labels = repeated[rng.permutation(n)]
    centers = [
        np.array([-1.40, 1.40]),
        np.array([-1.00, 0.00, 1.00]),
        np.array([-0.65, 0.65]),
    ]
    loadings = np.column_stack([centers[j][labels[:, j]] for j in range(3)])
    combined = labels[:, 0] * 6 + labels[:, 1] * 2 + labels[:, 2]
    return loadings, labels, combined


def profile_codes(labels: np.ndarray) -> np.ndarray:
    """Return stable integer codes for distinct rows of a membership matrix."""
    _, inverse = np.unique(np.asarray(labels, dtype=int), axis=0, return_inverse=True)
    return inverse


def _ensure_nonempty_columns(
    labels: np.ndarray,
    group_counts: tuple[int, ...],
    rng: np.random.Generator,
) -> np.ndarray:
    labels = labels.copy()
    for j, count in enumerate(group_counts):
        missing = sorted(set(range(count)) - set(np.unique(labels[:, j])))
        if missing:
            replacement = rng.choice(labels.shape[0], size=len(missing), replace=False)
            labels[replacement, j] = missing
    return labels


def loading_design(
    n: int,
    spec: DesignSpec,
    rng: np.random.Generator,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, tuple[int, ...], bool, list[np.ndarray]]:
    """Generate loading memberships and centers for a structural design."""
    if spec.structure == "crossed":
        loadings, labels, profiles = factor_labels(n, rng)
        centers = [
            np.array([-1.40, 1.40]),
            np.array([-1.00, 0.00, 1.00]),
            np.array([-0.65, 0.65]),
        ]
        group_counts = (2, 3, 2)
        orientation_identified = True
    elif spec.structure == "partial":
        group_counts = (2, 3, 2)
        first = rng.binomial(1, 0.50, size=n)
        second = np.empty(n, dtype=int)
        for i, group in enumerate(first):
            probabilities = [0.58, 0.32, 0.10] if group == 0 else [0.10, 0.32, 0.58]
            second[i] = int(rng.choice(3, p=probabilities))
        third = np.where(rng.random(n) < 0.75, first, 1 - first)
        labels = _ensure_nonempty_columns(
            np.column_stack([first, second, third]), group_counts, rng
        )
        centers = [
            np.array([-1.40, 1.40]),
            np.array([-1.00, 0.00, 1.00]),
            np.array([-0.65, 0.65]),
        ]
        loadings = np.column_stack(
            [centers[j][labels[:, j]] for j in range(len(group_counts))]
        )
        profiles = profile_codes(labels)
        orientation_identified = True
    elif spec.structure == "unbalanced":
        group_counts = (2, 3, 2)
        labels = np.column_stack(
            [
                rng.choice(2, size=n, p=[0.80, 0.20]),
                rng.choice(3, size=n, p=[0.65, 0.25, 0.10]),
                rng.choice(2, size=n, p=[0.85, 0.15]),
            ]
        )
        labels = _ensure_nonempty_columns(labels, group_counts, rng)
        centers = [
            np.array([-1.40, 1.40]),
            np.array([-1.00, 0.00, 1.00]),
            np.array([-0.65, 0.65]),
        ]
        loadings = np.column_stack(
            [centers[j][labels[:, j]] for j in range(len(group_counts))]
        )
        profiles = profile_codes(labels)
        orientation_identified = True
    elif spec.structure == "aligned":
        # Deliberate identification-boundary design: all coordinates share
        # one three-group partition.  The vector centers form a full-rank,
        # well-conditioned matrix, so the factor dimension remains r=3 even
        # though rotations preserve the common partition and make individual
        # coordinate labels nonunique.
        group_counts = (3, 3, 3)
        shared = np.arange(n) % 3
        shared = shared[rng.permutation(n)]
        labels = np.column_stack([shared, shared, shared])
        center_matrix = np.array(
            [
                [0.544, 0.380, 1.456],
                [1.455, -0.528, -0.405],
                [-0.384, -1.462, 0.525],
            ]
        )
        centers = [center_matrix[:, j] for j in range(3)]
        loadings = np.column_stack(
            [centers[j][labels[:, j]] for j in range(len(group_counts))]
        )
        profiles = profile_codes(labels)
        orientation_identified = False
    elif spec.structure == "pca_orientation":
        if spec.pca_orientation_rho is None:
            raise ValueError("pca_orientation requires pca_orientation_rho")
        rho = float(spec.pca_orientation_rho)
        if not 0.0 <= rho < 1.0:
            raise ValueError("pca_orientation_rho must lie in [0, 1)")

        # For the N=120 stress suite, these counts exactly realize
        # P(z1=z2=+/-1)=(1+rho)/4 and
        # P(z1=-z2)=(1-rho)/4.  The z3 allocations are equal within each
        # sign-opposed pair of (z1,z2) cells and sum to N/2 across z3=1.
        # This keeps all three margins exactly balanced and makes z3 exactly
        # orthogonal to z1 and z2 even when the pair-cell counts are odd.
        same_count = int(round(n * (1.0 + rho) / 4.0))
        different_count = n // 2 - same_count
        if 2 * (same_count + different_count) != n:
            raise ValueError(
                "N is incompatible with the requested exact orientation-stress probabilities"
            )
        if n % 4:
            raise ValueError(
                "N must be divisible by four to balance z3 exactly"
            )
        same_z3_ones = same_count // 2
        different_z3_ones = n // 4 - same_z3_ones
        if not 0 <= different_z3_ones <= different_count:
            raise ValueError("requested orientation stress is incompatible with z3 balance")
        pair_cells = [
            (0, 0, same_count, same_z3_ones),
            (1, 1, same_count, same_z3_ones),
            (0, 1, different_count, different_z3_ones),
            (1, 0, different_count, different_z3_ones),
        ]
        label_blocks = []
        for first, second, count, z3_ones in pair_cells:
            label_blocks.append(
                np.column_stack(
                    [
                        np.full(count, first, dtype=int),
                        np.full(count, second, dtype=int),
                        np.concatenate(
                            [
                                np.zeros(count - z3_ones, dtype=int),
                                np.ones(z3_ones, dtype=int),
                            ]
                        ),
                    ]
                )
            )
        labels = np.vstack(label_blocks)
        labels = labels[rng.permutation(n)]
        centers = [
            np.array([-1.10, 1.10]),
            np.array([-0.90, 0.90]),
            np.array([-0.60, 0.60]),
        ]
        group_counts = (2, 2, 2)
        loadings = np.column_stack(
            [centers[j][labels[:, j]] for j in range(len(group_counts))]
        )
        profiles = profile_codes(labels)
        orientation_identified = True
    else:
        raise ValueError(f"unknown loading structure: {spec.structure}")

    if spec.matched_separation:
        # Shrink only the first-coordinate gap while preserving its loading
        # second moment.  The other two balanced, mean-zero columns keep the
        # loading Gram matrix diagonal, so this is a separation experiment
        # rather than the original global weak-factor perturbation.
        raw = np.array([0.975, 1.725])
        target_rms = math.sqrt(float(np.mean(centers[0] ** 2)))
        centers[0] = raw * target_rms / math.sqrt(float(np.mean(raw**2)))
        loadings[:, 0] = centers[0][labels[:, 0]]

    loadings = spec.loading_scale * loadings
    centers = [spec.loading_scale * center for center in centers]
    if spec.loading_jitter > 0:
        loadings = loadings + spec.loading_jitter * rng.standard_normal(loadings.shape)
    return loadings, labels, profiles, group_counts, orientation_identified, centers


def generate_panel(
    n: int,
    t: int,
    scenario: str,
    rng: np.random.Generator,
) -> GeneratedPanel:
    if scenario not in DESIGNS:
        raise ValueError(f"unknown scenario {scenario!r}; choose from {sorted(DESIGNS)}")
    spec = DESIGNS[scenario]
    loadings, labels, profiles, group_counts, orientation_identified, centers = (
        loading_design(n, spec, rng)
    )

    phi = 0.30
    r = len(group_counts)
    innovations = rng.standard_normal((t, r))
    factors = np.empty_like(innovations)
    factors[0] = innovations[0]
    for time_index in range(1, t):
        factors[time_index] = (
            phi * factors[time_index - 1]
            + math.sqrt(1.0 - phi**2) * innovations[time_index]
        )
    gram = factors.T @ factors / t
    chol = np.linalg.cholesky(gram)
    factors = factors @ np.linalg.inv(chol.T)

    if spec.error_distribution == "t5":
        z = rng.standard_t(5, size=(n, t)) * math.sqrt(3.0 / 5.0)
    elif spec.error_distribution == "t3":
        z = rng.standard_t(3, size=(n, t)) / math.sqrt(3.0)
    elif spec.error_distribution == "contamination":
        z = rng.standard_normal((n, t))
        contaminated = rng.random((n, t)) < 0.05
        z[contaminated] = 5.0 * rng.standard_normal(int(np.sum(contaminated)))
        z = z / math.sqrt(0.95 + 0.05 * 25.0)
    else:
        z = rng.standard_normal((n, t))
    rho = spec.cross_rho
    errors = np.empty_like(z)
    errors[0] = z[0]
    for i in range(1, n):
        errors[i] = rho * errors[i - 1] + math.sqrt(1.0 - rho**2) * z[i]
    if spec.serial_rho:
        serial = np.empty_like(errors)
        serial[:, 0] = errors[:, 0]
        for time_index in range(1, t):
            serial[:, time_index] = (
                spec.serial_rho * serial[:, time_index - 1]
                + math.sqrt(1.0 - spec.serial_rho**2) * errors[:, time_index]
            )
        errors = serial
    if spec.heteroskedastic:
        scales = np.linspace(0.55, 1.45, n)
        scales = scales / math.sqrt(float(np.mean(scales**2)))
        errors = scales[:, None] * errors
    x = loadings @ factors.T + errors
    gram_eigenvalues = np.linalg.eigvalsh(loadings.T @ loadings / n)
    separations = [
        float(np.min(np.diff(np.sort(center)))) if len(center) > 1 else math.inf
        for center in centers
    ]
    loading_cross_moment_12 = float(loadings[:, 0] @ loadings[:, 1] / n)
    realized_pca_orientation_rho = (
        loading_cross_moment_12 / (1.10 * 0.90)
        if spec.pca_orientation_rho is not None
        else math.nan
    )
    common = loadings @ factors.T
    diagnostics: dict[str, float | int | str] = {
        "structure": spec.structure,
        "true_profiles": int(len(np.unique(profiles))),
        "orientation_identified": int(orientation_identified),
        "min_center_separation": float(min(separations)),
        "min_loading_eigenvalue": float(gram_eigenvalues[0]),
        "max_loading_eigenvalue": float(gram_eigenvalues[-1]),
        "signal_to_noise": float(np.sum(common**2) / np.sum(errors**2)),
        "loading_jitter": spec.loading_jitter,
        "cross_rho": spec.cross_rho,
        "serial_rho": spec.serial_rho,
        "pca_orientation_target_rho": (
            float(spec.pca_orientation_rho)
            if spec.pca_orientation_rho is not None
            else math.nan
        ),
        "pca_orientation_rho": (
            realized_pca_orientation_rho
            if spec.pca_orientation_rho is not None
            else math.nan
        ),
        "population_pca_rotation_degrees": (
            math.degrees(
                0.5
                * math.atan2(
                    1.98 * realized_pca_orientation_rho,
                    1.21 - 0.81,
                )
            )
            if spec.pca_orientation_rho is not None
            else math.nan
        ),
        "loading_cross_moment_12": loading_cross_moment_12,
    }
    diagnostics.update(
        {f"center_separation_{j + 1}": value for j, value in enumerate(separations)}
    )
    return GeneratedPanel(
        x=x,
        loadings=loadings,
        factors=factors,
        errors=errors,
        labels=labels,
        profiles=profiles,
        group_counts=group_counts,
        orientation_identified=orientation_identified,
        diagnostics=diagnostics,
    )


def admm_estimator(
    x: np.ndarray,
    group_counts: tuple[int, ...],
    alpha: float,
    rng: np.random.Generator,
    max_outer: int = CONFIG.max_outer,
    max_inner: int = CONFIG.max_inner,
    tolerance: float = CONFIG.residual_tolerance,
    return_diagnostics: bool = False,
    initialization: str = "pca",
    initial_solution: tuple[np.ndarray, np.ndarray] | None = None,
    perform_refit: bool = True,
    kappa_over_t: float = CONFIG.kappa_over_t,
) -> (
    tuple[np.ndarray, np.ndarray, np.ndarray, float]
    | tuple[np.ndarray, np.ndarray, np.ndarray, float, dict[str, Any]]
):
    """Least-squares ADMM estimator described in Algorithms 1-2."""
    n, t = x.shape
    r = len(group_counts)
    kappa = kappa_over_t * float(t)
    if initialization == "warm":
        if initial_solution is None:
            raise ValueError("warm initialization requires initial_solution")
        loadings, factors = (np.asarray(value, dtype=float).copy() for value in initial_solution)
        if loadings.shape != (n, r) or factors.shape != (t, r):
            raise ValueError("initial_solution has incompatible dimensions")
    elif initialization == "pca":
        loadings, factors = pca_estimator(x, r)
    elif initialization == "rotated-pca":
        loadings, factors = pca_estimator(x, r)
        rotation, _ = np.linalg.qr(rng.standard_normal((r, r)))
        loadings = loadings @ rotation
        factors = factors @ rotation
    elif initialization == "random":
        q, _ = np.linalg.qr(rng.standard_normal((t, r)))
        factors = math.sqrt(t) * q[:, :r]
        loadings = x @ factors / t
    else:
        raise ValueError(
            "initialization must be 'warm', 'pca', 'rotated-pca', or 'random'"
        )
    theta = loadings.copy()
    dual = np.zeros_like(loadings)
    centers = []
    for j, count in enumerate(group_counts):
        center, _, _ = exact_kmedians_1d(theta[:, j], count)
        centers.append(center)

    previous_objective = math.inf
    converged = False
    scaled_primal = math.inf
    scaled_dual = math.inf
    split_objective = math.inf
    objective = math.inf
    outer_iteration = 0
    relative_objective_change = math.inf
    center_update_rejections = 0
    fit_start = time.perf_counter()
    for outer_iteration in range(1, max_outer + 1):
        # Smooth factor-loading block.
        for _ in range(max_inner):
            old_loadings = loadings.copy()
            old_factors = factors.copy()
            loadings = (2.0 * x @ factors + kappa * theta - dual) / (2.0 * t + kappa)
            factors = procrustes_factor(x, loadings)
            change = (
                np.mean((loadings - old_loadings) ** 2)
                + np.mean((factors - old_factors) ** 2)
            )
            if change < CONFIG.smooth_change_tolerance:
                break

        # Factor-separable p=1 proximal and K-medians block.
        old_theta = theta.copy()
        target = loadings + dual / kappa
        labels = np.zeros((n, r), dtype=int)
        for j, count in enumerate(group_counts):
            for _ in range(CONFIG.center_max_iter):
                nearest = np.argmin(
                    np.abs(target[:, j, None] - centers[j][None, :]), axis=1
                )
                difference = target[:, j] - centers[j][nearest]
                theta[:, j] = centers[j][nearest] + np.sign(difference) * np.maximum(
                    np.abs(difference) - alpha / kappa, 0.0
                )
                current_loss = float(
                    np.min(
                        np.abs(theta[:, j, None] - centers[j][None, :]), axis=1
                    ).sum()
                )
                new_centers, new_labels, new_loss = exact_kmedians_1d(
                    theta[:, j], count
                )
                if new_loss > current_loss + CONFIG.center_objective_tolerance * max(
                    1.0, current_loss
                ):
                    center_update_rejections += 1
                    labels[:, j] = np.argmin(
                        np.abs(theta[:, j, None] - centers[j][None, :]), axis=1
                    )
                    break
                labels[:, j] = new_labels
                if np.max(np.abs(new_centers - centers[j])) < CONFIG.center_tolerance:
                    centers[j] = new_centers
                    break
                centers[j] = new_centers

        primal = loadings - theta
        dual_residual = kappa * (theta - old_theta)
        dual = dual + kappa * primal
        penalty = 0.0
        for j in range(r):
            # Evaluate the original criterion at Lambda.  Before primal
            # feasibility, labels obtained from Theta need not be nearest for
            # Lambda and therefore cannot be reused for this diagnostic.
            penalty += np.min(
                np.abs(loadings[:, j, None] - centers[j][None, :]), axis=1
            ).sum()
        objective = float(np.sum((x - loadings @ factors.T) ** 2) + alpha * penalty)
        split_penalty = 0.0
        for j in range(r):
            split_penalty += np.min(
                np.abs(theta[:, j, None] - centers[j][None, :]), axis=1
            ).sum()
        split_objective = float(
            np.sum((x - loadings @ factors.T) ** 2) + alpha * split_penalty
        )
        scaled_primal = np.linalg.norm(primal) / math.sqrt(n * r)
        scaled_dual = np.linalg.norm(dual_residual) / (kappa * math.sqrt(n * r))
        relative_objective_change = abs(previous_objective - objective) / max(
            1.0, abs(objective)
        )
        if (
            scaled_primal < tolerance
            and scaled_dual < tolerance
            and relative_objective_change < CONFIG.objective_tolerance
        ):
            converged = True
            break
        previous_objective = objective

    discovery_objective = objective
    discovery_split_objective = split_objective
    split_original_gap = abs(discovery_split_objective - discovery_objective) / max(
        1.0, abs(discovery_objective)
    )
    elapsed = time.perf_counter() - fit_start

    # Algorithm 1 labels final Theta by the final centers.  Only after that
    # assignment are inactive and coincident centers collapsed for the refit.
    active_centers = []
    active_counts = []
    for j in range(r):
        center, labels[:, j] = collapse_active_centers(
            theta[:, j], centers[j], CONFIG.center_merge_tolerance
        )
        active_centers.append(center)
        active_counts.append(len(center))
    active_group_counts = tuple(active_counts)
    # Multistart selection depends on the discovery objective, not the refit.
    # Saving the exact RNG state lets mdsp_multistart defer this comparatively
    # expensive step until after it has selected one start, while reproducing
    # the refit that the selected start would have obtained here.
    refit_rng_state = copy.deepcopy(rng.bit_generator.state)
    if perform_refit:
        loadings, factors = factor_specific_refit(
            x, labels, active_group_counts, rng
        )
        objective = float(np.sum((x - loadings @ factors.T) ** 2))
    else:
        objective = math.nan
    if converged:
        failure_reason = ""
    elif not np.isfinite(
        [scaled_primal, scaled_dual, relative_objective_change, discovery_objective]
    ).all():
        failure_reason = "nonfinite_value"
    elif scaled_primal >= tolerance:
        failure_reason = "primal_not_converged"
    elif scaled_dual >= tolerance:
        failure_reason = "dual_not_converged"
    elif relative_objective_change >= CONFIG.objective_tolerance:
        failure_reason = "objective_not_stable"
    else:
        failure_reason = "max_outer_iter"
    diagnostics: dict[str, Any] = {
        "iterations": outer_iteration,
        "converged": int(converged),
        "failure_reason": failure_reason,
        "scaled_primal": float(scaled_primal),
        "scaled_dual": float(scaled_dual),
        "relative_objective_change": float(relative_objective_change),
        "discovery_objective": float(discovery_objective),
        "split_objective": float(discovery_split_objective),
        "split_original_gap": float(split_original_gap),
        "refit_rss": objective,
        "runtime_seconds": float(elapsed),
        "kappa_over_t": float(kappa_over_t),
        "requested_group_counts": ",".join(map(str, group_counts)),
        "active_group_counts": ",".join(map(str, active_group_counts)),
        "collapsed_centers": int(sum(group_counts) - sum(active_group_counts)),
        "center_update_rejections": center_update_rejections,
        "final_centers": json.dumps([center.tolist() for center in active_centers]),
    }
    if not perform_refit:
        diagnostics["_refit_rng_state"] = refit_rng_state
    if return_diagnostics:
        return loadings, factors, labels, objective, diagnostics
    return loadings, factors, labels, objective


def validation_mse(loadings: np.ndarray, validation: np.ndarray) -> float:
    """Return least-squares holdout reconstruction error using a pseudoinverse."""
    coefficients = np.linalg.lstsq(loadings, validation, rcond=None)[0]
    return float(np.mean((validation - loadings @ coefficients) ** 2))


def validation_alpha(
    x: np.ndarray,
    group_counts: tuple[int, ...],
    rng: np.random.Generator,
    return_diagnostics: bool = False,
    training_fraction: float = CONFIG.validation_fraction,
    grid_ratios: tuple[float, ...] = CONFIG.alpha_ratios,
    cv_starts: int = CONFIG.cv_starts,
    max_outer: int = CONFIG.cv_max_outer,
) -> float | None | tuple[float | None, list[dict[str, Any]]]:
    """Select alpha after retrying each initially failed multistart candidate."""
    _, t = x.shape
    if not 0.5 <= training_fraction < 1.0:
        raise ValueError("training_fraction must lie in [0.5, 1)")
    split = max(20, int(training_fraction * t))
    split = min(split, t - 10)
    train, validation = x[:, :split], x[:, split:]
    grid = [float(value * math.sqrt(split)) for value in grid_ratios]
    records: list[dict[str, Any]] = []
    final_records: dict[float, dict[str, Any]] = {}
    converged_solutions: dict[float, tuple[np.ndarray, np.ndarray]] = {}

    def make_seed_bank(starts: int) -> tuple[int, ...]:
        return tuple(int(rng.integers(0, 2**32 - 1)) for _ in range(starts))

    def fit_candidate(
        alpha: float,
        attempt: int,
        starts: int,
        attempt_max_outer: int,
        start_seeds: tuple[int, ...],
        warm_seed: int,
        warm_solution: tuple[np.ndarray, np.ndarray] | None,
        kappa_over_t: float,
    ) -> tuple[dict[str, Any], tuple[np.ndarray, np.ndarray] | None]:
        loadings, factors, _, _, diagnostics = mdsp_multistart(
            train,
            group_counts,
            alpha,
            rng,
            starts=starts,
            max_outer=attempt_max_outer,
            max_inner=CONFIG.cv_max_inner,
            warm_start=warm_solution,
            start_seeds=start_seeds,
            warm_seed=warm_seed,
            kappa_over_t=kappa_over_t,
        )
        score = validation_mse(loadings, validation)
        record: dict[str, Any] = {
            "tuning_attempt": attempt,
            "alpha_train": alpha,
            "alpha_over_sqrt_train": alpha / math.sqrt(split),
            "training_fraction": split / t,
            "training_observations": split,
            "validation_observations": t - split,
            "validation_mse": score,
            "active_group_counts": diagnostics["active_group_counts"],
            "converged": int(diagnostics["converged"]),
            "failure_reason": diagnostics["failure_reason"],
            "attempted_starts": diagnostics["attempted_starts"],
            "converged_starts": diagnostics["converged_starts"],
            "start_allocation": diagnostics["start_allocation"],
            "scaled_primal": float(diagnostics["scaled_primal"]),
            "scaled_dual": float(diagnostics["scaled_dual"]),
            "kappa_over_t": float(kappa_over_t),
            "selected": 0,
            "final_candidate": 1,
        }
        solution = (loadings, factors) if diagnostics["converged"] else None
        return record, solution

    initial_seeds = make_seed_bank(cv_starts)
    initial_warm_seed = int(rng.integers(0, 2**32 - 1))
    warm_solution: tuple[np.ndarray, np.ndarray] | None = None
    for alpha in grid:
        record, solution = fit_candidate(
            alpha,
            1,
            cv_starts,
            max_outer,
            initial_seeds,
            initial_warm_seed,
            warm_solution,
            CONFIG.kappa_over_t,
        )
        records.append(record)
        final_records[alpha] = record
        if solution is not None:
            converged_solutions[alpha] = solution
            warm_solution = solution

    failed_alphas = [alpha for alpha in grid if not final_records[alpha]["converged"]]
    if failed_alphas:
        retry_seeds = make_seed_bank(CONFIG.cv_retry_starts)
        retry_warm_seed = int(rng.integers(0, 2**32 - 1))
        for alpha in failed_alphas:
            lower_alphas = [value for value in converged_solutions if value < alpha]
            retry_warm = (
                converged_solutions[max(lower_alphas)] if lower_alphas else None
            )
            record, solution = fit_candidate(
                alpha,
                2,
                CONFIG.cv_retry_starts,
                CONFIG.cv_retry_max_outer,
                retry_seeds,
                retry_warm_seed,
                retry_warm,
                CONFIG.kappa_over_t,
            )
            final_records[alpha]["final_candidate"] = 0
            records.append(record)
            final_records[alpha] = record
            if solution is not None:
                converged_solutions[alpha] = solution

    # Do not alter the tuning path of a replication that already has at least
    # one valid candidate.  Only an otherwise-invalid replication enters this
    # deterministic emergency tier: first extend the original penalty to 480
    # iterations, then try the pre-specified larger ADMM penalties with the
    # same seed bank and iteration budget.
    if not any(row["converged"] for row in final_records.values()):
        emergency_penalties = (CONFIG.kappa_over_t, *CONFIG.kappa_retry_ratios)
        for alpha in grid:
            lower_alphas = [value for value in converged_solutions if value < alpha]
            emergency_warm = (
                converged_solutions[max(lower_alphas)] if lower_alphas else None
            )
            for offset, kappa_over_t in enumerate(emergency_penalties, start=3):
                record, solution = fit_candidate(
                    alpha,
                    offset,
                    CONFIG.cv_retry_starts,
                    CONFIG.cv_emergency_max_outer,
                    retry_seeds,
                    retry_warm_seed,
                    emergency_warm,
                    kappa_over_t,
                )
                final_records[alpha]["final_candidate"] = 0
                records.append(record)
                final_records[alpha] = record
                if solution is not None:
                    converged_solutions[alpha] = solution
                    break

    converged_records = [row for row in final_records.values() if row["converged"]]
    if not converged_records:
        if return_diagnostics:
            return None, records
        return None
    selected = min(converged_records, key=lambda row: row["validation_mse"])
    selected["selected"] = 1
    best_alpha = float(selected["alpha_train"])
    transferred = best_alpha * math.sqrt(t / split)
    if return_diagnostics:
        return transferred, records
    return transferred


def pca_kmeans_estimator(
    x: np.ndarray,
    group_counts: tuple[int, ...],
    rng: np.random.Generator,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    loadings, _ = pca_estimator(x, len(group_counts))
    labels = np.zeros_like(loadings, dtype=int)
    for j, count in enumerate(group_counts):
        centers, labels[:, j], _ = kmeans_1d(
            loadings[:, j], count, rng, n_init=CONFIG.pca_kmeans_starts
        )
    loadings, factors = factor_specific_refit(x, labels, group_counts, rng)
    return loadings, factors, labels


def pca_vector_kmeans_estimator(
    x: np.ndarray,
    r: int,
    vector_groups: int,
    rng: np.random.Generator,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """PCA followed by one K-means partition of complete loading vectors."""
    pca_loadings, _ = pca_estimator(x, r)
    _, labels, _ = kmeans_nd(
        pca_loadings, vector_groups, rng, n_init=CONFIG.vector_kmeans_starts
    )
    loadings, factors = common_vector_refit(x, labels, r, rng)
    return loadings, factors, labels


def oracle_estimator(
    x: np.ndarray,
    labels: np.ndarray,
    group_counts: tuple[int, ...],
    rng: np.random.Generator,
) -> tuple[np.ndarray, np.ndarray]:
    return factor_specific_refit(
        x, labels, group_counts, rng, n_init=CONFIG.factor_refit_starts
    )


def best_alignment(
    estimated_loadings: np.ndarray,
    estimated_factors: np.ndarray,
    true_loadings: np.ndarray,
    true_factors: np.ndarray,
    group_counts: tuple[int, ...],
) -> tuple[np.ndarray, np.ndarray, tuple[int, ...], np.ndarray]:
    r = true_loadings.shape[1]
    if len(group_counts) != r:
        raise ValueError("group_counts must have one entry per factor")
    best = None
    for permutation in itertools.permutations(range(r)):
        if any(group_counts[permutation[j]] != group_counts[j] for j in range(r)):
            continue
        score = 0.0
        for j in range(r):
            truth = true_loadings[:, j]
            estimate = estimated_loadings[:, permutation[j]]
            score += abs(float(truth @ estimate)) / (
                np.linalg.norm(truth) * np.linalg.norm(estimate) + 1e-15
            )
        if best is None or score > best[0]:
            best = (score, permutation)
    assert best is not None
    permutation = best[1]
    signs = np.array(
        [
            1.0
            if true_loadings[:, j] @ estimated_loadings[:, permutation[j]] >= 0
            else -1.0
            for j in range(r)
        ]
    )
    return (
        estimated_loadings[:, permutation] * signs,
        estimated_factors[:, permutation] * signs,
        permutation,
        signs,
    )


def label_accuracy(estimated: np.ndarray, truth: np.ndarray) -> tuple[float, np.ndarray]:
    values_est = np.unique(estimated)
    values_true = np.unique(truth)
    # Use a bijection when the group counts agree.  Under a badly estimated
    # factor permutation the counts can differ; the modal map then gives a
    # well-defined misclassification diagnostic while exact recovery is
    # separately ruled out below.
    if len(values_est) == len(values_true):
        k = len(values_est)
        contingency = np.zeros((k, k), dtype=int)
        est_index = {value: index for index, value in enumerate(values_est)}
        true_index = {value: index for index, value in enumerate(values_true)}
        for estimated_value, true_value in zip(estimated, truth):
            contingency[est_index[estimated_value], true_index[true_value]] += 1

        # Exact dynamic-programming assignment.  Unlike enumerating all k!
        # label permutations, this remains fast for the 12-profile comparison.
        states: dict[int, tuple[int, tuple[int, ...]]] = {0: (0, ())}
        for row in range(k):
            updated: dict[int, tuple[int, tuple[int, ...]]] = {}
            for mask, (score, assignment) in states.items():
                for column in range(k):
                    if mask & (1 << column):
                        continue
                    new_mask = mask | (1 << column)
                    candidate = (
                        score + int(contingency[row, column]),
                        assignment + (column,),
                    )
                    if new_mask not in updated or candidate[0] > updated[new_mask][0]:
                        updated[new_mask] = candidate
            states = updated
        best_score, assignment = states[(1 << k) - 1]
        mapping = {
            values_est[row]: values_true[assignment[row]] for row in range(k)
        }
        mapped = np.array([mapping[value] for value in estimated])
        return float(best_score / estimated.size), mapped
    mapping = {}
    for value in values_est:
        members = truth[estimated == value]
        counts = [(candidate, int(np.sum(members == candidate))) for candidate in values_true]
        mapping[value] = max(counts, key=lambda item: item[1])[0]
    mapped = np.array([mapping[value] for value in estimated])
    return float(np.mean(mapped == truth)), mapped


def adjusted_rand_index(labels_a: np.ndarray, labels_b: np.ndarray) -> float:
    values_a, inv_a = np.unique(labels_a, return_inverse=True)
    values_b, inv_b = np.unique(labels_b, return_inverse=True)
    table = np.zeros((len(values_a), len(values_b)), dtype=int)
    np.add.at(table, (inv_a, inv_b), 1)

    def choose2(values: np.ndarray) -> float:
        return float(np.sum(values * (values - 1) / 2.0))

    n = labels_a.size
    total_pairs = n * (n - 1) / 2.0
    sum_cells = choose2(table)
    sum_rows = choose2(table.sum(axis=1))
    sum_cols = choose2(table.sum(axis=0))
    expected = sum_rows * sum_cols / total_pairs if total_pairs else 0.0
    maximum = 0.5 * (sum_rows + sum_cols)
    if abs(maximum - expected) < 1e-12:
        return 1.0
    return (sum_cells - expected) / (maximum - expected)


def metrics(
    loadings: np.ndarray,
    factors: np.ndarray,
    labels: np.ndarray | None,
    true_loadings: np.ndarray,
    true_factors: np.ndarray,
    true_labels: np.ndarray,
    true_profiles: np.ndarray,
    group_counts: tuple[int, ...],
    estimated_profiles: np.ndarray | None = None,
    orientation_identified: bool = True,
    coordinate_comparable: bool = True,
) -> dict[str, float | str]:
    aligned_l, aligned_f, permutation, _ = best_alignment(
        loadings, factors, true_loadings, true_factors, group_counts
    )
    common = loadings @ factors.T
    true_common = true_loadings @ true_factors.T
    result = {
        "alignment_permutation": ",".join(str(value) for value in permutation),
        "loading_rmse": (
            float(np.sqrt(np.mean((aligned_l - true_loadings) ** 2)))
            if orientation_identified and coordinate_comparable
            else math.nan
        ),
        "factor_rmse": (
            float(np.sqrt(np.mean((aligned_f - true_factors) ** 2)))
            if orientation_identified and coordinate_comparable
            else math.nan
        ),
        "common_re": float(
            np.linalg.norm(common - true_common) / np.linalg.norm(true_common)
        ),
        "mcr": math.nan,
        "ari": math.nan,
        "exact": math.nan,
        "profile_mcr": math.nan,
        "profile_ari": math.nan,
        "profile_exact": math.nan,
    }
    for j in range(true_loadings.shape[1]):
        comparable = orientation_identified and coordinate_comparable
        result[f"factor_{j + 1}_alignment_cosine"] = (
            abs(float(true_loadings[:, j] @ aligned_l[:, j]))
            / (
                np.linalg.norm(true_loadings[:, j])
                * np.linalg.norm(aligned_l[:, j])
                + 1e-15
            )
            if comparable
            else math.nan
        )
        result[f"factor_{j + 1}_loading_rmse"] = (
            float(np.sqrt(np.mean((aligned_l[:, j] - true_loadings[:, j]) ** 2)))
            if comparable
            else math.nan
        )
        result[f"factor_{j + 1}_factor_rmse"] = (
            float(np.sqrt(np.mean((aligned_f[:, j] - true_factors[:, j]) ** 2)))
            if comparable
            else math.nan
        )
        result[f"factor_{j + 1}_mcr"] = math.nan
        result[f"factor_{j + 1}_ari"] = math.nan
    if labels is not None and orientation_identified:
        accuracies, aris, exact = [], [], True
        for j in range(true_labels.shape[1]):
            candidate = labels[:, permutation[j]]
            accuracy, mapped = label_accuracy(candidate, true_labels[:, j])
            accuracies.append(accuracy)
            factor_ari = adjusted_rand_index(candidate, true_labels[:, j])
            aris.append(factor_ari)
            result[f"factor_{j + 1}_mcr"] = 1.0 - accuracy
            result[f"factor_{j + 1}_ari"] = factor_ari
            for group in range(group_counts[j]):
                true_members = true_labels[:, j] == group
                true_size = int(np.sum(true_members))
                recall = (
                    float(np.mean(mapped[true_members] == group))
                    if true_size
                    else math.nan
                )
                prefix = f"factor_{j + 1}_group_{group + 1}"
                result[f"{prefix}_recall"] = recall
                result[f"{prefix}_error"] = 1.0 - recall
                result[f"{prefix}_estimated_size"] = int(np.sum(mapped == group))
            exact = (
                exact
                and len(np.unique(candidate)) == len(np.unique(true_labels[:, j]))
                and bool(np.all(mapped == true_labels[:, j]))
            )
        result["mcr"] = 1.0 - float(np.mean(accuracies))
        result["ari"] = float(np.mean(aris))
        result["exact"] = float(exact)
    if estimated_profiles is None and labels is not None:
        estimated_profiles = profile_codes(labels)
    if estimated_profiles is not None:
        profile_accuracy, mapped_profiles = label_accuracy(
            np.asarray(estimated_profiles), np.asarray(true_profiles)
        )
        result["profile_mcr"] = 1.0 - profile_accuracy
        result["profile_ari"] = adjusted_rand_index(
            np.asarray(estimated_profiles), np.asarray(true_profiles)
        )
        result["profile_exact"] = float(
            len(np.unique(estimated_profiles)) == len(np.unique(true_profiles))
            and bool(np.all(mapped_profiles == true_profiles))
        )
    return result


def mdsp_multistart(
    x: np.ndarray,
    group_counts: tuple[int, ...],
    alpha: float,
    rng: np.random.Generator,
    starts: int = CONFIG.final_starts,
    max_outer: int = CONFIG.max_outer,
    max_inner: int = CONFIG.max_inner,
    warm_start: tuple[np.ndarray, np.ndarray] | None = None,
    start_seeds: tuple[int, ...] | None = None,
    warm_seed: int | None = None,
    kappa_over_t: float = CONFIG.kappa_over_t,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, float, dict[str, Any]]:
    """Select a converged MDSP solution across structurally different starts."""
    has_warm = warm_start is not None
    if start_seeds is None:
        start_seeds = tuple(
            int(rng.integers(0, 2**32 - 1)) for _ in range(starts)
        )
    if len(start_seeds) != starts:
        raise ValueError("start_seeds must contain one seed per total start budget")

    # The seed bank is semantic: PCA, all rotations, then random starts.  A
    # continuation replaces only the last rotation, so every retained base
    # start uses the same seed at every alpha candidate.
    full_initializations = base_initializations(starts)
    retained_indices = list(range(len(full_initializations)))
    if has_warm:
        rotation_indices = [
            index
            for index, initialization in enumerate(full_initializations)
            if initialization == "rotated-pca"
        ]
        replace_index = rotation_indices[-1] if rotation_indices else retained_indices[-1]
        retained_indices.remove(replace_index)
    start_specs = [
        (full_initializations[index], start_seeds[index])
        for index in retained_indices
    ]
    if has_warm:
        if warm_seed is None:
            warm_seed = int(rng.integers(0, 2**32 - 1))
        start_specs.insert(0, ("warm", warm_seed))

    candidates = []
    for initialization, seed in start_specs:
        result = admm_estimator(
            x,
            group_counts,
            alpha,
            np.random.default_rng(seed),
            max_outer=max_outer,
            max_inner=max_inner,
            return_diagnostics=True,
            initialization=initialization,
            initial_solution=warm_start if initialization == "warm" else None,
            perform_refit=False,
            kappa_over_t=kappa_over_t,
        )
        diagnostics = result[4]
        rank = (
            0 if diagnostics["converged"] else 1,
            (
                diagnostics["discovery_objective"]
                if diagnostics["converged"]
                else diagnostics["scaled_primal"] + diagnostics["scaled_dual"]
            ),
        )
        candidates.append((rank, initialization, seed, result))
    selected = min(candidates, key=lambda item: item[0])
    result = selected[3]
    diagnostics = dict(result[4])
    refit_rng_state = diagnostics.pop("_refit_rng_state")
    refit_rng = np.random.default_rng()
    refit_rng.bit_generator.state = refit_rng_state
    active_group_counts = tuple(
        int(value) for value in diagnostics["active_group_counts"].split(",")
    )
    refit_loadings, refit_factors = factor_specific_refit(
        x,
        result[2],
        active_group_counts,
        refit_rng,
    )
    refit_objective = float(
        np.sum((x - refit_loadings @ refit_factors.T) ** 2)
    )
    diagnostics["refit_rss"] = refit_objective
    diagnostics.update(
        {
            "attempted_starts": len(start_specs),
            "converged_starts": sum(item[3][4]["converged"] for item in candidates),
            "selected_initialization": selected[1],
            "selected_start_seed": selected[2],
            "start_allocation": json.dumps(
                start_allocation(starts, has_warm=has_warm), sort_keys=True
            ),
            "selected_start_runtime_seconds": diagnostics["runtime_seconds"],
        }
    )
    return (
        refit_loadings,
        refit_factors,
        result[2],
        refit_objective,
        diagnostics,
    )


def mdsp_full_sample_with_retry(
    x: np.ndarray,
    group_counts: tuple[int, ...],
    alpha: float,
    rng: np.random.Generator,
    initial_starts: int = CONFIG.final_starts,
    retry_starts: int = CONFIG.final_retry_starts,
    initial_max_outer: int = CONFIG.max_outer,
    retry_max_outer: int = CONFIG.final_retry_max_outer,
    kappa_retry_ratios: tuple[float, ...] = CONFIG.kappa_retry_ratios,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, float, dict[str, Any]]:
    """Apply the uniform full-sample retry rule after an all-start failure."""
    if retry_starts < initial_starts:
        raise ValueError("retry_starts must be at least initial_starts")

    # Generate the expanded bank before either attempt.  The initial fit uses
    # its first seeds; retry repeats those starts with a larger iteration budget
    # and adds the remaining starts.  Thus retry is an expansion, not a fresh
    # draw chosen after inspecting a failed replication.
    seed_bank = tuple(
        int(rng.integers(0, 2**32 - 1)) for _ in range(retry_starts)
    )
    initial_start = time.perf_counter()
    initial = mdsp_multistart(
        x,
        group_counts,
        alpha,
        rng,
        starts=initial_starts,
        max_outer=initial_max_outer,
        start_seeds=seed_bank[:initial_starts],
        kappa_over_t=CONFIG.kappa_over_t,
    )
    initial_runtime = time.perf_counter() - initial_start
    initial_diagnostics = dict(initial[4])
    common_diagnostics = {
        "initial_final_fit_converged": int(initial_diagnostics["converged"]),
        "initial_final_failure_reason": initial_diagnostics["failure_reason"],
        "initial_final_scaled_primal": float(
            initial_diagnostics["scaled_primal"]
        ),
        "initial_final_scaled_dual": float(initial_diagnostics["scaled_dual"]),
        "initial_final_relative_objective_change": float(
            initial_diagnostics["relative_objective_change"]
        ),
        "initial_final_iterations": int(initial_diagnostics["iterations"]),
        "initial_final_converged_starts": int(
            initial_diagnostics["converged_starts"]
        ),
        "initial_final_fit_runtime_seconds": initial_runtime,
    }
    if initial_diagnostics["converged"]:
        diagnostics = initial_diagnostics
        diagnostics.update(
            {
                **common_diagnostics,
                "final_fit_attempt": 1,
                "final_fit_retried": 0,
                "retry_recovered": 0,
                "retry_final_fit_runtime_seconds": 0.0,
                "total_attempted_starts": initial_starts,
            }
        )
        return initial[0], initial[1], initial[2], initial[3], diagnostics

    retry_start = time.perf_counter()
    retry = mdsp_multistart(
        x,
        group_counts,
        alpha,
        rng,
        starts=retry_starts,
        max_outer=retry_max_outer,
        start_seeds=seed_bank,
        kappa_over_t=CONFIG.kappa_over_t,
    )
    retry_runtime = time.perf_counter() - retry_start
    selected_retry = retry
    retry_attempts = 1
    if not retry[4]["converged"]:
        for kappa_over_t in kappa_retry_ratios:
            penalty_retry_start = time.perf_counter()
            candidate = mdsp_multistart(
                x,
                group_counts,
                alpha,
                rng,
                starts=retry_starts,
                max_outer=retry_max_outer,
                start_seeds=seed_bank,
                kappa_over_t=kappa_over_t,
            )
            retry_runtime += time.perf_counter() - penalty_retry_start
            retry_attempts += 1
            selected_retry = candidate
            if candidate[4]["converged"]:
                break
    diagnostics = dict(selected_retry[4])
    diagnostics.update(
        {
            **common_diagnostics,
            "final_fit_attempt": 1 + retry_attempts,
            "final_fit_retried": 1,
            "retry_recovered": int(diagnostics["converged"]),
            "retry_final_fit_runtime_seconds": retry_runtime,
            "total_attempted_starts": initial_starts + retry_attempts * retry_starts,
        }
    )
    return (
        selected_retry[0],
        selected_retry[1],
        selected_retry[2],
        selected_retry[3],
        diagnostics,
    )


def run_one(
    n: int,
    t: int,
    scenario: str,
    seed: int,
    include_vector_benchmarks: bool = False,
    mdsp_starts: int = CONFIG.final_starts,
) -> list[dict[str, float | str | int]]:
    rng_dgp, method_rng = replication_rngs(seed)
    rng_pcakm = method_rng["pca_kmeans"]
    rng_tuning = method_rng["tuning"]
    rng_mdsp = method_rng["mdsp"]
    rng_oracle = method_rng["oracle_fs"]
    rng_cv_budget = method_rng["cv_budget"]
    rng_cv_profile = method_rng["cv_profile"]
    rng_oracle_cv = method_rng["oracle_cv"]
    panel = generate_panel(n, t, scenario, rng_dgp)
    x = panel.x
    true_l = panel.loadings
    true_f = panel.factors
    true_labels = panel.labels
    true_profiles = panel.profiles
    group_counts = panel.group_counts
    r = len(group_counts)
    output = []

    fit_start = time.perf_counter()
    pca_l, pca_f = pca_estimator(x, r)
    output.append(
        {
            "method": "PCA",
            "continuous_loading_parameters": n * r,
            "runtime_seconds": time.perf_counter() - fit_start,
            **metrics(
                pca_l,
                pca_f,
                None,
                true_l,
                true_f,
                true_labels,
                true_profiles,
                group_counts,
                orientation_identified=panel.orientation_identified,
            ),
        }
    )

    fit_start = time.perf_counter()
    pca_l, pca_f, pca_labels = pca_kmeans_estimator(x, group_counts, rng_pcakm)
    output.append(
        {
            "method": "PCA-KM",
            "continuous_loading_parameters": sum(group_counts),
            "runtime_seconds": time.perf_counter() - fit_start,
            **metrics(
                pca_l,
                pca_f,
                pca_labels,
                true_l,
                true_f,
                true_labels,
                true_profiles,
                group_counts,
                estimated_profiles=profile_codes(pca_labels),
                orientation_identified=panel.orientation_identified,
            ),
        }
    )

    fit_start = time.perf_counter()
    alpha, validation_records = validation_alpha(
        x,
        group_counts,
        rng_tuning,
        return_diagnostics=True,
        max_outer=CONFIG.cv_max_outer,
    )
    tuning_runtime_seconds = time.perf_counter() - fit_start
    final_fit_start = time.perf_counter()
    if alpha is not None:
        mdsp_l, mdsp_f, mdsp_labels, _, mdsp_diagnostics = (
            mdsp_full_sample_with_retry(
                x,
                group_counts,
                alpha,
                rng_mdsp,
                initial_starts=mdsp_starts,
            )
        )
        raw_mdsp_metrics = metrics(
            mdsp_l,
            mdsp_f,
            mdsp_labels,
            true_l,
            true_f,
            true_labels,
            true_profiles,
            group_counts,
            estimated_profiles=profile_codes(mdsp_labels),
            orientation_identified=panel.orientation_identified,
        )
        statistical_fit_valid = int(bool(mdsp_diagnostics["converged"]))
        end_to_end_exact = (
            raw_mdsp_metrics["exact"] if statistical_fit_valid else 0.0
        )
        end_to_end_profile_exact = (
            raw_mdsp_metrics["profile_exact"] if statistical_fit_valid else 0.0
        )
        mdsp_metrics = raw_mdsp_metrics
        if not mdsp_diagnostics["converged"]:
            mdsp_metrics = {key: math.nan for key in mdsp_metrics}
        selected_validation = next(
            row for row in validation_records if row["selected"] == 1
        )
        tuning_valid = 1
    else:
        metric_names = metrics(
            pca_l,
            pca_f,
            None,
            true_l,
            true_f,
            true_labels,
            true_profiles,
            group_counts,
        )
        mdsp_metrics = {key: math.nan for key in metric_names}
        selected_validation = None
        tuning_valid = 0
        statistical_fit_valid = 0
        end_to_end_exact = 0.0 if panel.orientation_identified else math.nan
        end_to_end_profile_exact = 0.0
        mdsp_diagnostics = {
            "iterations": 0,
            "converged": 0,
            "failure_reason": "no_converged_tuning_candidate",
            "scaled_primal": math.nan,
            "scaled_dual": math.nan,
            "relative_objective_change": math.nan,
            "discovery_objective": math.nan,
            "split_objective": math.nan,
            "split_original_gap": math.nan,
            "refit_rss": math.nan,
            "attempted_starts": 0,
            "converged_starts": 0,
            "selected_initialization": "",
            "start_allocation": "",
            "selected_start_runtime_seconds": math.nan,
            "initial_final_fit_converged": 0,
            "initial_final_failure_reason": "not_run",
            "initial_final_scaled_primal": math.nan,
            "initial_final_scaled_dual": math.nan,
            "initial_final_relative_objective_change": math.nan,
            "initial_final_iterations": 0,
            "initial_final_converged_starts": 0,
            "initial_final_fit_runtime_seconds": 0.0,
            "final_fit_attempt": 0,
            "final_fit_retried": 0,
            "retry_recovered": 0,
            "retry_final_fit_runtime_seconds": 0.0,
            "total_attempted_starts": 0,
            "collapsed_centers": math.nan,
            "center_update_rejections": math.nan,
            "active_group_counts": "",
            "final_centers": "",
        }
    final_fit_runtime_seconds = time.perf_counter() - final_fit_start
    total_runtime_seconds = time.perf_counter() - fit_start
    active_loading_parameters = (
        sum(int(value) for value in mdsp_diagnostics["active_group_counts"].split(","))
        if mdsp_diagnostics["active_group_counts"]
        else math.nan
    )
    output.append(
        {
            "method": "MDSP",
            "alpha_over_sqrt_t": (
                alpha / math.sqrt(t) if alpha is not None else math.nan
            ),
            "validation_mse": (
                selected_validation["validation_mse"]
                if selected_validation is not None
                else math.nan
            ),
            "tuning_fit_converged": tuning_valid,
            "tuning_attempt": (
                selected_validation["tuning_attempt"]
                if selected_validation is not None
                else 2
            ),
            "tuning_candidates_converged": sum(
                row["converged"]
                for row in validation_records
                if row["final_candidate"]
            ),
            "tuning_candidates_retried": sum(
                row["tuning_attempt"] == 2 for row in validation_records
            ),
            "statistical_fit_valid": statistical_fit_valid,
            "end_to_end_exact": end_to_end_exact,
            "end_to_end_profile_exact": end_to_end_profile_exact,
            "continuous_loading_parameters": active_loading_parameters,
            **mdsp_diagnostics,
            "tuning_runtime_seconds": tuning_runtime_seconds,
            "final_fit_runtime_seconds": final_fit_runtime_seconds,
            "runtime_seconds": total_runtime_seconds,
            **mdsp_metrics,
        }
    )

    fit_start = time.perf_counter()
    oracle_l, oracle_f = oracle_estimator(x, true_labels, group_counts, rng_oracle)
    output.append(
        {
            "method": "Oracle-FS",
            "continuous_loading_parameters": sum(group_counts),
            "runtime_seconds": time.perf_counter() - fit_start,
            **metrics(
                oracle_l,
                oracle_f,
                None,
                true_l,
                true_f,
                true_labels,
                true_profiles,
                group_counts,
                orientation_identified=panel.orientation_identified,
            ),
        }
    )

    if include_vector_benchmarks:
        profile_count = len(np.unique(true_profiles))
        budget_groups = max(1, sum(group_counts) // r)
        for method, vector_groups, method_rng in [
            ("CV-KM-budget", budget_groups, rng_cv_budget),
            ("CV-KM-profile", profile_count, rng_cv_profile),
        ]:
            fit_start = time.perf_counter()
            cv_l, cv_f, cv_labels = pca_vector_kmeans_estimator(
                x, r, vector_groups, method_rng
            )
            output.append(
                {
                    "method": method,
                    "vector_groups": vector_groups,
                    "continuous_loading_parameters": r * vector_groups,
                    "runtime_seconds": time.perf_counter() - fit_start,
                    **metrics(
                        cv_l,
                        cv_f,
                        None,
                        true_l,
                        true_f,
                        true_labels,
                        true_profiles,
                        group_counts,
                        estimated_profiles=cv_labels,
                        orientation_identified=panel.orientation_identified,
                        coordinate_comparable=False,
                    ),
                }
            )

        fit_start = time.perf_counter()
        oracle_cv_l, oracle_cv_f = common_vector_refit(
            x,
            true_profiles,
            r,
            rng_oracle_cv,
            n_init=CONFIG.common_vector_refit_starts,
        )
        output.append(
            {
                "method": "Oracle-CV",
                "vector_groups": profile_count,
                "continuous_loading_parameters": r * profile_count,
                "runtime_seconds": time.perf_counter() - fit_start,
                **metrics(
                    oracle_cv_l,
                    oracle_cv_f,
                    None,
                    true_l,
                    true_f,
                    true_labels,
                    true_profiles,
                    group_counts,
                    orientation_identified=panel.orientation_identified,
                    coordinate_comparable=False,
                ),
            }
        )

    true_group_sizes = {
        f"factor_{factor + 1}_group_{group + 1}_true_size": int(
            np.sum(true_labels[:, factor] == group)
        )
        for factor, count in enumerate(group_counts)
        for group in range(count)
    }
    for row in output:
        row.setdefault("statistical_fit_valid", 1)
        row.update(
            {
                "N": n,
                "T": t,
                "scenario": scenario,
                "seed": seed,
                "group_counts": ",".join(map(str, group_counts)),
                **true_group_sizes,
                **panel.diagnostics,
            }
        )
    return output


def run_task(task: tuple[int, int, str, int, bool, int]) -> list[dict[str, Any]]:
    """Pickle-friendly wrapper used for streaming multiprocessing results."""
    return run_one(*task)


def summarize(rows: list[dict[str, float | str | int]]) -> list[dict[str, float | str | int]]:
    def numeric(value: Any) -> float:
        if value in (None, ""):
            return math.nan
        return float(value)

    groups: dict[tuple, list[dict]] = defaultdict(list)
    for row in rows:
        groups[
            (
                str(row["scenario"]),
                int(row["N"]),
                int(row["T"]),
                str(row["method"]),
            )
        ].append(row)
    summary = []
    metrics_to_average = [
        "loading_rmse",
        "factor_rmse",
        "common_re",
        "mcr",
        "ari",
        "exact",
        "profile_mcr",
        "profile_ari",
        "profile_exact",
        "end_to_end_exact",
        "end_to_end_profile_exact",
        "alpha_over_sqrt_t",
        "validation_mse",
        "tuning_fit_converged",
        "tuning_candidates_converged",
        "tuning_candidates_retried",
        "statistical_fit_valid",
        "continuous_loading_parameters",
        "runtime_seconds",
        "tuning_runtime_seconds",
        "final_fit_runtime_seconds",
        "initial_final_fit_runtime_seconds",
        "retry_final_fit_runtime_seconds",
        "selected_start_runtime_seconds",
        "initial_final_fit_converged",
        "initial_final_scaled_primal",
        "initial_final_scaled_dual",
        "initial_final_relative_objective_change",
        "initial_final_iterations",
        "initial_final_converged_starts",
        "final_fit_attempt",
        "final_fit_retried",
        "retry_recovered",
        "total_attempted_starts",
        "iterations",
        "converged",
        "attempted_starts",
        "converged_starts",
        "scaled_primal",
        "scaled_dual",
        "relative_objective_change",
        "split_original_gap",
        "collapsed_centers",
        "center_update_rejections",
        "discovery_objective",
        "split_objective",
        "refit_rss",
        "true_profiles",
        "orientation_identified",
        "min_center_separation",
        "center_separation_1",
        "center_separation_2",
        "center_separation_3",
        "min_loading_eigenvalue",
        "max_loading_eigenvalue",
        "signal_to_noise",
        "pca_orientation_target_rho",
        "pca_orientation_rho",
        "population_pca_rotation_degrees",
        "loading_cross_moment_12",
    ]
    metrics_to_average.extend(
        sorted(
            {
                field
                for row in rows
                for field in row
                if field.startswith("factor_") and field not in metrics_to_average
            }
        )
    )
    for key, members in sorted(groups.items()):
        scenario, n, t, method = key
        result: dict[str, float | str | int] = {
            "scenario": scenario,
            "N": n,
            "T": t,
            "method": method,
            "replications": len(members),
            "group_counts": members[0].get("group_counts", ""),
            "structure": members[0].get("structure", ""),
        }
        failure_counts: dict[str, int] = defaultdict(int)
        for member in members:
            reason = str(member.get("failure_reason", ""))
            if reason:
                failure_counts[reason] += 1
        result["failure_reason_counts"] = json.dumps(
            dict(sorted(failure_counts.items())), sort_keys=True
        )
        initial_failure_counts: dict[str, int] = defaultdict(int)
        for member in members:
            reason = str(member.get("initial_final_failure_reason", ""))
            if reason and reason != "not_run":
                initial_failure_counts[reason] += 1
        result["initial_final_failure_reason_counts"] = json.dumps(
            dict(sorted(initial_failure_counts.items())), sort_keys=True
        )
        for metric in metrics_to_average:
            values = np.array([numeric(x.get(metric, math.nan)) for x in members])
            finite = values[np.isfinite(values)]
            result[f"n_{metric}"] = int(finite.size)
            result[metric] = float(finite.mean()) if finite.size else math.nan
            result[f"se_{metric}"] = (
                float(finite.std(ddof=1) / math.sqrt(finite.size))
                if finite.size > 1
                else math.nan
            )
            if metric in {
                "runtime_seconds",
                "tuning_runtime_seconds",
                "final_fit_runtime_seconds",
                "initial_final_fit_runtime_seconds",
                "retry_final_fit_runtime_seconds",
            }:
                result[f"median_{metric}"] = (
                    float(np.median(finite)) if finite.size else math.nan
                )
                result[f"q25_{metric}"] = (
                    float(np.quantile(finite, 0.25)) if finite.size else math.nan
                )
                result[f"q75_{metric}"] = (
                    float(np.quantile(finite, 0.75)) if finite.size else math.nan
                )
        summary.append(result)
    return summary


def write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = sorted({key for row in rows for key in row})
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def write_csv_atomic(path: Path, rows: list[dict]) -> None:
    """Write a CSV checkpoint without exposing a partially written file."""
    temporary = path.with_suffix(path.suffix + ".tmp")
    write_csv(temporary, rows)
    temporary.replace(path)


def parse_dimensions(value: str) -> list[tuple[int, int]]:
    """Parse a comma-separated N-by-T grid such as ``60x60,120x60``."""
    dimensions: list[tuple[int, int]] = []
    for raw_item in value.split(","):
        item = raw_item.strip().lower()
        pieces = item.split("x")
        if len(pieces) != 2:
            raise ValueError(f"invalid dimension {raw_item!r}; expected NxT")
        try:
            n, t = (int(piece.strip()) for piece in pieces)
        except ValueError as error:
            raise ValueError(f"invalid dimension {raw_item!r}; expected NxT") from error
        if n <= 0 or t <= 0:
            raise ValueError("N and T must be positive")
        dimensions.append((n, t))
    if not dimensions:
        raise ValueError("at least one dimension is required")
    if len(dimensions) != len(set(dimensions)):
        raise ValueError("dimensions must not contain duplicates")
    return dimensions


def publication_designs(suite: str) -> list[tuple[int, int, str]]:
    """Return named, auditable design collections used by the command line."""
    baseline_dimensions = [
        (60, 60, "baseline"),
        (120, 60, "baseline"),
        (60, 120, "baseline"),
        (120, 120, "baseline"),
    ]
    if suite == "structure":
        return [
            (120, 120, "baseline"),
            (120, 120, "partial"),
            (120, 120, "unbalanced"),
            (120, 120, "aligned_boundary"),
        ]
    if suite == "separation":
        return [
            (120, 120, "baseline"),
            (120, 120, "separation_matched"),
            (120, 120, "weak"),
            (120, 120, "approximate"),
        ]
    if suite == "stress":
        return [
            (120, 120, "baseline"),
            (120, 120, "heavy"),
            (120, 120, "t3"),
            (120, 120, "contamination"),
            (120, 120, "dependence"),
            (120, 120, "serial"),
            (120, 120, "heteroskedastic"),
        ]
    if suite == "scaling":
        return [
            (size, size, scenario)
            for scenario in ("partial", "unbalanced")
            for size in (60, 120, 240)
        ]
    if suite == "orientation_stress":
        return [
            (120, 120, scenario)
            for scenario in (
                "pca_orientation_rho_0",
                "pca_orientation_rho_10",
                "pca_orientation_rho_20",
                "pca_orientation_rho_30",
                "pca_orientation_rho_40",
                "pca_orientation_rho_50",
                "pca_orientation_rho_60",
                "pca_orientation_rho_70",
                "pca_orientation_rho_80",
            )
        ]
    if suite == "publication":
        extra = [
            "weak",
            "separation_matched",
            "approximate",
            "partial",
            "unbalanced",
            "aligned_boundary",
            "heavy",
            "t3",
            "contamination",
            "dependence",
            "serial",
            "heteroskedastic",
        ]
        return baseline_dimensions + [(120, 120, name) for name in extra]
    raise ValueError(f"unknown suite: {suite}")


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Reproducible simulation suites for factor-specific loading groups"
    )
    parser.add_argument("--reps", type=int, default=50)
    parser.add_argument("--seed", type=int, default=20260819)
    parser.add_argument(
        "--suite",
        choices=[
            "structure",
            "separation",
            "stress",
            "scaling",
            "orientation_stress",
            "publication",
        ],
        default="publication",
        help="named evidence module to run (default: publication)",
    )
    parser.add_argument(
        "--designs",
        default=None,
        help="optional comma-separated scenario override",
    )
    parser.add_argument(
        "--dimensions",
        default=None,
        help="optional comma-separated NxT grid used with --designs (default: 120x120)",
    )
    parser.add_argument(
        "--output",
        type=Path,
        required=True,
        help="directory for this run; existing results are protected by default",
    )
    parser.add_argument("--workers", type=int, default=1)
    parser.add_argument("--quick", action="store_true")
    parser.add_argument(
        "--overwrite",
        action="store_true",
        help="allow replacement of known result files in a nonempty output directory",
    )
    parser.add_argument(
        "--vector-benchmarks",
        action=argparse.BooleanOptionalAction,
        default=None,
        help="include common-vector competitors (suite-dependent by default)",
    )
    parser.add_argument("--list-designs", action="store_true")
    args = parser.parse_args()

    if args.list_designs:
        for name, spec in DESIGNS.items():
            print(f"{name:20s} {spec}")
        return
    if args.reps <= 0:
        parser.error("--reps must be positive")
    if args.workers <= 0:
        parser.error("--workers must be positive")

    if args.quick:
        designs = [(60, 60, "baseline")]
        replications = min(args.reps, 2)
    elif args.designs:
        requested = [value.strip() for value in args.designs.split(",") if value.strip()]
        unknown = sorted(set(requested) - set(DESIGNS))
        if unknown:
            parser.error(f"unknown scenarios: {', '.join(unknown)}")
        try:
            dimensions = (
                parse_dimensions(args.dimensions)
                if args.dimensions
                else [(120, 120)]
            )
        except ValueError as error:
            parser.error(str(error))
        designs = [
            (n, t, name)
            for n, t in dimensions
            for name in requested
        ]
        replications = args.reps
    else:
        if args.dimensions:
            parser.error("--dimensions requires --designs")
        designs = publication_designs(args.suite)
        replications = args.reps

    include_vector_benchmarks = args.vector_benchmarks
    if include_vector_benchmarks is None:
        include_vector_benchmarks = args.suite in {
            "structure",
            "separation",
            "publication",
        }

    start = time.time()
    seed_sequence = np.random.SeedSequence(args.seed)
    child_seeds = seed_sequence.spawn(len(designs) * replications)
    basic_tasks = []
    counter = 0
    for n, t, scenario in designs:
        for replication in range(replications):
            seed = int(child_seeds[counter].generate_state(1)[0])
            counter += 1
            basic_tasks.append((n, t, scenario, seed))

    known_outputs = [
        "replication_results.csv",
        "summary.csv",
        "run_metadata.json",
        "replication_results.incomplete.csv",
    ]
    existing_outputs = [name for name in known_outputs if (args.output / name).exists()]
    if existing_outputs and not args.overwrite:
        parser.error(
            f"output directory already contains {', '.join(existing_outputs)}; "
            "choose a new --output or pass --overwrite deliberately"
        )
    args.output.mkdir(parents=True, exist_ok=True)
    tasks = [
        (*task, bool(include_vector_benchmarks), CONFIG.final_starts)
        for task in basic_tasks
    ]
    rows: list[dict[str, Any]] = []
    checkpoint_path = args.output / "replication_results.incomplete.csv"
    if args.workers > 1:
        with mp.get_context("spawn").Pool(args.workers) as pool:
            results = pool.imap(run_task, tasks, chunksize=1)
            for index, result in enumerate(results, start=1):
                rows.extend(result)
                if index % CHECKPOINT_EVERY == 0:
                    write_csv_atomic(checkpoint_path, rows)
                if index % max(1, min(10, len(tasks))) == 0:
                    print(
                        f"completed {index}/{len(tasks)} design-replications",
                        flush=True,
                    )
    else:
        for index, task in enumerate(tasks, start=1):
            rows.extend(run_task(task))
            if index % CHECKPOINT_EVERY == 0:
                write_csv_atomic(checkpoint_path, rows)
            if index % max(1, min(10, len(tasks))) == 0:
                print(
                    f"completed {index}/{len(tasks)} design-replications",
                    flush=True,
                )
    summary = summarize(rows)
    write_csv(args.output / "replication_results.csv", rows)
    write_csv(args.output / "summary.csv", summary)

    metadata = {
        "suite": "custom" if args.designs else args.suite,
        "requested_suite": args.suite,
        "designs_override": args.designs,
        "dimensions_override": args.dimensions,
        "designs": designs,
        "replications": replications,
        "seed": args.seed,
        "workers": args.workers,
        "vector_benchmarks": bool(include_vector_benchmarks),
        "numerical_settings": asdict(CONFIG),
        "start_allocation": {
            "final": start_allocation(CONFIG.final_starts),
            "final_retry": start_allocation(CONFIG.final_retry_starts),
            "validation_initial": start_allocation(CONFIG.cv_starts),
            "validation_continuation": start_allocation(
                CONFIG.cv_starts, has_warm=True
            ),
            "validation_retry": start_allocation(CONFIG.cv_retry_starts),
            "validation_retry_continuation": start_allocation(
                CONFIG.cv_retry_starts, has_warm=True
            ),
        },
        "center_solver": "exact_dynamic_programming_1d_kmedians",
        "final_label_rule": "nearest_final_center_from_final_theta",
        "final_retry_policy": (
            "after_base_retry_failure_reuse_the_same_seed_bank_at_"
            "kappa_over_t_2_then_4"
        ),
        "tuning_emergency_policy": (
            "only_if_no_candidate_converges_after_standard_retry; use_480_"
            "outer_iterations_at_kappa_over_t_1_then_2_then_4"
        ),
        "alignment_score": "absolute_cosine_similarity_restricted_to_equal_group_counts",
        "rng_streams": "historical_dgp_stream_plus_method_specific_child_streams",
        "method_seed_namespace": METHOD_SEED_NAMESPACE,
        "method_stream_names": METHOD_STREAM_NAMES,
        "tuning_seed_policy": "shared_base_start_seed_bank_across_alpha",
        "checkpoint_every_design_replications": CHECKPOINT_EVERY,
        "command": sys.argv,
        "elapsed_seconds": time.time() - start,
        "python_version": platform.python_version(),
        "python_executable": sys.executable,
        "numpy_version": np.__version__,
    }
    with (args.output / "run_metadata.json").open("w", encoding="utf-8") as stream:
        json.dump(metadata, stream, indent=2)
    checkpoint_path.unlink(missing_ok=True)
    print(f"Completed in {time.time() - start:.1f} seconds")


if __name__ == "__main__":
    main()
